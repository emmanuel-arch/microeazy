# -----------------------------------------------------------------------------
# INSTALL THE LENDER NODE - elevated PowerShell, in the kit folder:
#
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Sql -Pbx -Publish
#
#   -Sql       the SQL relay as a service      (127.0.0.1:8787)
#   -Pbx       the PBX bridge as a service     (127.0.0.1:10001)
#   -Publish   Tailscale: unattended mode on, then Funnel
#              https://<node>.<tailnet>.ts.net:8443  -> the SQL relay
#              https://<node>.<tailnet>.ts.net:10000 -> the PBX bridge
#   -Remove    stop and delete both services and both Funnel mappings
#   -Nssm      path to nssm.exe if it is neither on PATH nor in this folder
#   -AsSystem  run the services as LocalSystem instead of LocalService
#
# Safe to run again: an existing service is replaced, not duplicated.
#
# The services run as NT AUTHORITY\LocalService (no admin rights, no network
# identity). The kit folder is closed to everyone but Administrators, SYSTEM and
# that account, and .env - which holds the SQL password - is readable by those
# three only, so a non-admin on this server cannot read it or swap the code.
# -----------------------------------------------------------------------------
param(
  [switch]$Sql,
  [switch]$Pbx,
  [switch]$Publish,
  [switch]$Remove,
  [string]$Nssm = "",
  [switch]$AsSystem,
  # The tailnet machine this kit is for. It refuses any other, so it cannot land
  # on the SQL Server (`services`) by an RDP window opened on the wrong box.
  [string]$Node = "lms"
)

# Continue, not Stop: under Stop, Windows PowerShell 5.1 turns any line a native
# tool (nssm, tailscale) writes to stderr into a terminating error. Failures that
# matter are checked explicitly below.
$ErrorActionPreference = "Continue"
$root = $PSScriptRoot
$SQL_SVC = "LenderNodeSqlRelay"
$PBX_SVC = "LenderNodePbxBridge"

function Ok($s)   { Write-Host "  [ OK ] $s" -ForegroundColor Green }
function Warn($s) { Write-Host "  [WARN] $s" -ForegroundColor Yellow }
function Die($s)  { Write-Host "  [STOP] $s" -ForegroundColor Red; exit 1 }
function Head($s) { Write-Host ""; Write-Host $s -ForegroundColor White }

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) { Die "run this from an elevated PowerShell (Run as administrator)" }
if (-not ($Sql -or $Pbx -or $Publish -or $Remove)) { Die "nothing to do: pass -Sql, -Pbx, -Publish (or -Remove). Run check-node.ps1 first." }

# --- Tools --------------------------------------------------------------------
if (-not $Nssm) {
  $cmd = Get-Command nssm -ErrorAction SilentlyContinue
  if ($cmd) { $Nssm = $cmd.Source } elseif (Test-Path (Join-Path $root "nssm.exe")) { $Nssm = Join-Path $root "nssm.exe" }
}
$ts = $null
$cmd = Get-Command tailscale -ErrorAction SilentlyContinue
if ($cmd) { $ts = $cmd.Source } elseif (Test-Path "C:\Program Files\Tailscale\tailscale.exe") { $ts = "C:\Program Files\Tailscale\tailscale.exe" }

if (-not $Remove) {
  if (-not $ts) { Die "tailscale.exe not found" }
  $here = $null
  try { $here = "$(((& $ts status --json 2>$null | Out-String) | ConvertFrom-Json).Self.DNSName)".Split(".")[0] } catch {}
  if (-not $here) { Die "could not read this machine's tailnet name (tailscale status)" }
  if ($here -ne $Node) { Die "this server is '$here' on the tailnet, not '$Node'. Open the RDP session on $Node, or pass -Node $here if installing here is deliberate." }
}

function Remove-Svc($name) {
  if (Get-Service $name -ErrorAction SilentlyContinue) {
    if ($Nssm) { & $Nssm stop $name 2>&1 | Out-Null; & $Nssm remove $name confirm 2>&1 | Out-Null }
    else { Stop-Service $name -Force -ErrorAction SilentlyContinue; sc.exe delete $name | Out-Null }
    Ok "removed service $name"
  }
}

# --- Remove -------------------------------------------------------------------
if ($Remove) {
  Head "Removing the lender node"
  Remove-Svc $SQL_SVC
  Remove-Svc $PBX_SVC
  if ($ts) {
    & $ts funnel --https=8443 off 2>&1 | Out-Null
    & $ts funnel --https=10000 off 2>&1 | Out-Null
    Ok "Funnel 8443 and 10000 turned off"
    & $ts funnel status
  }
  Write-Host ""
  exit 0
}

# --- Settings -----------------------------------------------------------------
$envFile = Join-Path $root ".env"
if (($Sql -or $Pbx) -and -not (Test-Path $envFile)) { Die "no .env in $root - copy .env.example to .env and fill it in" }
$cfg = @{}
if (Test-Path $envFile) {
  foreach ($line in Get-Content $envFile) {
    if ($line -match '^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$') {
      $v = $Matches[2]
      if ($v.Length -ge 2 -and (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'")))) { $v = $v.Substring(1, $v.Length - 2) }
      $cfg[$Matches[1]] = $v
    }
  }
}

Head "Checking .env"
if ($Sql) {
  if (-not $cfg["SERVICESUITE_RELAY_SECRET"] -or $cfg["SERVICESUITE_RELAY_SECRET"].Length -lt 32) { Die "SERVICESUITE_RELAY_SECRET must be at least 32 characters" }
  if (-not $cfg["SERVICESUITE_CONN_MICROMART"]) { Die "SERVICESUITE_CONN_MICROMART is empty" }
  if (-not $cfg["MICROMART_FINTECH"]) { Warn "MICROMART_FINTECH is empty: loan posting into entity 3005 cannot use this relay" }
  # A relay host that itself names relays treats every lender as configured and
  # answers for books it holds no password for.
  foreach ($k in $cfg.Keys) { if ($k -like "SERVICESUITE_RELAY_URL*") { Die "$k must not be set on a relay host - delete that line" } }
  foreach ($k in $cfg.Keys) {
    if ($k -like "SERVICESUITE_CONN_*" -and $k -ne "SERVICESUITE_CONN_MICROMART" -and $cfg[$k]) { Die "$k is another lender's book: only Micromart's connection strings belong on Micromart's server" }
  }
  Ok "SQL relay settings present (writes: $(if ($cfg['SQL_RELAY_ALLOW_WRITES'] -eq 'true') { 'ARMED' } else { 'refused' }))"
}
if ($Pbx) {
  if (-not $cfg["BRIDGE_SECRET"] -or $cfg["BRIDGE_SECRET"].Length -lt 24) { Die "BRIDGE_SECRET must be at least 24 characters" }
  if (-not $cfg["PBX_ALLOW"]) { Die "PBX_ALLOW is empty (check-node.ps1 prints it)" }
  if ($cfg["CONNECTDESK_URL"] -or $cfg["CRON_SECRET"]) { Warn "CONNECTDESK_URL/CRON_SECRET set: this bridge will also tick EVERY organisation's floor each minute" }
  Ok "PBX bridge settings present ($($cfg['PBX_ALLOW']))"
}

# --- Services -----------------------------------------------------------------
if ($Sql -or $Pbx) {
  $nodeCmd = (Get-Command node -ErrorAction SilentlyContinue)
  if (-not $nodeCmd) { Die "node is not installed (Node 24 LTS x64), or this PowerShell was opened before it was - open a new one" }
  if (-not $Nssm) { Die "nssm.exe not found: put win64\nssm.exe from https://nssm.cc/download in this folder, or pass -Nssm" }
  $nodeExe = $nodeCmd.Source
  if (-not (Test-Path (Join-Path $root "sql-relay.cjs")) -or -not (Test-Path (Join-Path $root "pbx-bridge.mjs"))) { Die "sql-relay.cjs / pbx-bridge.mjs missing: unzip the whole kit here" }

  Head "Permissions"
  $logs = Join-Path $root "logs"
  if (-not (Test-Path $logs)) { New-Item -ItemType Directory $logs | Out-Null }
  # *S-1-5-32-544 Administrators, *S-1-5-18 SYSTEM, *S-1-5-19 LOCAL SERVICE.
  # Set on the folder; the files inside inherit it.
  icacls $root /inheritance:r /grant:r "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-19:(OI)(CI)RX" /C /Q 2>&1 | Out-Null
  if ($LASTEXITCODE -ne 0) { Die "could not set permissions on $root" }
  icacls $logs /grant "*S-1-5-19:(OI)(CI)M" /C /Q 2>&1 | Out-Null
  icacls $envFile /inheritance:r /grant:r "*S-1-5-32-544:F" "*S-1-5-18:F" "*S-1-5-19:R" /C /Q 2>&1 | Out-Null
  if ($LASTEXITCODE -ne 0) { Die "could not lock down .env" }
  Ok "${root}: Administrators, SYSTEM and LocalService (read) only; logs writable; .env readable by those three"
  Warn "edit .env from now on with an elevated editor (notepad, Run as administrator)"

  function Install-Svc($name, $entry, $what) {
    Remove-Svc $name
    & $Nssm install $name $nodeExe $entry 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Die "nssm could not install $name" }
    & $Nssm set $name AppDirectory $root | Out-Null
    & $Nssm set $name DisplayName "Lender node - $what" | Out-Null
    & $Nssm set $name Description "Connected Suite lender node: $what. Kit in $root, see README.md." | Out-Null
    & $Nssm set $name Start SERVICE_AUTO_START | Out-Null
    & $Nssm set $name AppStdout (Join-Path $logs "$name.log") | Out-Null
    & $Nssm set $name AppStderr (Join-Path $logs "$name.log") | Out-Null
    & $Nssm set $name AppRotateFiles 1 | Out-Null
    & $Nssm set $name AppRotateOnline 1 | Out-Null
    & $Nssm set $name AppRotateBytes 10485760 | Out-Null
    # Come back after any exit, five seconds later; NSSM throttles a crash loop.
    & $Nssm set $name AppExit Default Restart | Out-Null
    & $Nssm set $name AppRestartDelay 5000 | Out-Null
    if (-not $AsSystem) {
      # Through WMI: Windows PowerShell 5.1 drops the empty password argument sc.exe needs.
      $w = Get-CimInstance Win32_Service -Filter "Name='$name'"
      $r = Invoke-CimMethod -InputObject $w -MethodName Change -Arguments @{ StartName = "NT AUTHORITY\LocalService"; StartPassword = "" }
      if ($r.ReturnValue -ne 0) { Die "could not set $name to run as LocalService (WMI code $($r.ReturnValue)); rerun with -AsSystem" }
    }
    # And if the wrapper itself dies, the service manager restarts it.
    sc.exe failure $name reset= 86400 actions= restart/5000/restart/5000/restart/30000 | Out-Null
    & $Nssm start $name 2>&1 | Out-Null
    Ok "service $name installed and started ($(if ($AsSystem) { 'LocalSystem' } else { 'LocalService' }))"
  }

  function Wait-Health($port, $name) {
    for ($i = 0; $i -lt 20; $i++) {
      try { $h = Invoke-RestMethod -Uri "http://127.0.0.1:$port/health" -TimeoutSec 3; if ($h.ok) { return $h } } catch {}
      Start-Sleep -Milliseconds 1500
    }
    Warn "$name did not answer on 127.0.0.1:$port/health within 30 s - read logs\$name.log"
    return $null
  }

  Head "Services"
  if ($Sql) {
    Install-Svc $SQL_SVC "sql-relay.cjs" "SQL relay (127.0.0.1:8787)"
    $h = Wait-Health 8787 $SQL_SVC
    if ($h) { Ok "SQL relay answering: writes $(if ($h.writes) { 'ARMED' } else { 'refused' }), $($h.allowedProcs) allowed proc(s)" }
  }
  if ($Pbx) {
    Install-Svc $PBX_SVC "pbx-bridge.mjs" "PBX bridge (127.0.0.1:10001)"
    $h = Wait-Health 10001 $PBX_SVC
    if ($h) { Ok "PBX bridge answering: allow $($h.allow -join ', '); pinned $(@($h.pinned).Count)" }
  }
}

# --- Publish ------------------------------------------------------------------
if ($Publish) {
  if (-not $ts) { Die "tailscale.exe not found" }
  Head "Tailscale"
  # Unattended: tailscaled keeps the node online with nobody signed in. Without
  # it, signing out of RDP takes the node - and both URLs - off the internet.
  & $ts set --unattended=true 2>&1 | Out-Null
  if ($LASTEXITCODE -eq 0) { Ok "unattended mode on" } else { Warn "could not set unattended mode here: Tailscale tray icon -> Preferences -> Run unattended" }
  $svc = Get-Service Tailscale -ErrorAction SilentlyContinue
  if ($svc -and $svc.StartType -ne "Automatic") { Set-Service Tailscale -StartupType Automatic; Ok "Tailscale service set to start automatically" }

  if ($Sql -or (Get-Service $SQL_SVC -ErrorAction SilentlyContinue)) {
    & $ts funnel --bg --https=8443 http://127.0.0.1:8787
    if ($LASTEXITCODE -ne 0) { Die "Funnel refused 8443 - is Funnel allowed for this node (admin console, Access controls)?" }
  }
  if ($Pbx -or (Get-Service $PBX_SVC -ErrorAction SilentlyContinue)) {
    & $ts funnel --bg --https=10000 http://127.0.0.1:10001
    if ($LASTEXITCODE -ne 0) { Die "Funnel refused 10000" }
  }
  Head "Funnel status - check that every mapping you expect is listed"
  & $ts funnel status
  $self = $null
  try { $self = ((& $ts status --json 2>$null | Out-String) | ConvertFrom-Json).Self } catch {}
  if ($self) {
    $dns = $self.DNSName.TrimEnd(".")
    Write-Host ""
    Ok "SQL relay:  https://${dns}:8443   (Vercel: SERVICESUITE_RELAY_URL_MICROMART)"
    Ok "PBX bridge: https://${dns}:10000  (ConnectDesk: Settings -> Phone system -> Telephony bridge URL)"
    if ($self.KeyExpiry) { Warn "this node's key expires $($self.KeyExpiry): admin console -> Machines -> this node -> Disable key expiry" }
  }
}

Write-Host ""
Write-Host "Next: reboot this server (or restart both services) and confirm both come back - see README.md." -ForegroundColor Yellow
Write-Host ""
