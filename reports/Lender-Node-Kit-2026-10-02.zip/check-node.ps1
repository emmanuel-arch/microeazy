# -----------------------------------------------------------------------------
# LENDER NODE CHECK - run FIRST, on the server, in an elevated PowerShell:
#
#   powershell -ExecutionPolicy Bypass -File check-node.ps1
#
# Read-only: it changes nothing. It answers what the .env and the install
# depend on - Node, NSSM, Tailscale (unattended, key expiry, Funnel), free ports,
# which road reaches Micromart's SQL Server, which road reaches the PBX API (and
# its certificate fingerprint when that road is HTTPS), the public egress
# address, and the clock (relay signatures are valid for 120 s).
# -----------------------------------------------------------------------------
param(
  # The tailnet machine this kit is for (the first label of its MagicDNS name).
  [string]$Node    = "lms",
  [string]$SqlLan  = "192.168.0.234",
  [string]$SqlTail = "100.72.35.56",
  [int]   $SqlPort = 4230,
  [string]$PbxLan  = "192.168.1.150",
  [string]$PbxWan  = "197.248.211.105",
  [int]   $PbxPort = 8088
)

$ErrorActionPreference = "Continue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Ok($s)   { Write-Host "  [ OK ] $s" -ForegroundColor Green }
function No($s)   { Write-Host "  [FAIL] $s" -ForegroundColor Red }
function Warn($s) { Write-Host "  [WARN] $s" -ForegroundColor Yellow }
function Note($s) { Write-Host "         $s" -ForegroundColor DarkGray }
function Head($s) { Write-Host ""; Write-Host $s -ForegroundColor White }

# A TCP connect with a 4 s ceiling (Test-NetConnection pings first and takes 20 s to fail).
function Test-Tcp([string]$h, [int]$p) {
  $c = New-Object Net.Sockets.TcpClient
  try {
    $iar = $c.BeginConnect($h, $p, $null, $null)
    if (-not $iar.AsyncWaitHandle.WaitOne(4000)) { return $false }
    $c.EndConnect($iar)
    return $c.Connected
  } catch { return $false } finally { $c.Close() }
}

# "https <SHA-256> (<subject>, <protocol>)" when the port speaks TLS, "http"
# when it answers plain HTTP, $null when it answers neither. TLS is tried first:
# some servers answer a plain request on a TLS port with an HTTP error page.
function Get-WebKind([string]$h, [int]$p) {
  $c = New-Object Net.Sockets.TcpClient
  try {
    $iar = $c.BeginConnect($h, $p, $null, $null)
    if ($iar.AsyncWaitHandle.WaitOne(4000)) {
      $c.EndConnect($iar)
      # Accept any certificate here: this reads the fingerprint, it trusts nothing.
      $cb = [Net.Security.RemoteCertificateValidationCallback] { param($s, $cert, $chain, $errors) return $true }
      $ssl = New-Object Net.Security.SslStream($c.GetStream(), $false, $cb)
      $ssl.ReadTimeout = 6000
      $any = [Security.Authentication.SslProtocols]::Tls12 -bor [Security.Authentication.SslProtocols]::Tls11 -bor [Security.Authentication.SslProtocols]::Tls
      $ssl.AuthenticateAsClient($h, $null, $any, $false)
      $x = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
      $sha = [Security.Cryptography.SHA256]::Create().ComputeHash([byte[]]$x.RawData)
      $proto = "$($ssl.SslProtocol)"
      if ($proto -ne "Tls12" -and $proto -ne "Tls13") { Warn "${h}:$p negotiated $proto; Node needs TLS 1.2 - tell the developer before installing the bridge" }
      return "https " + (($sha | ForEach-Object { $_.ToString("X2") }) -join ":") + " (" + $x.Subject + ", $proto)"
    }
  } catch { } finally { $c.Close() }
  # Plain HTTP: a raw HEAD, because Invoke-WebRequest in Windows PowerShell 5.1
  # throws without a response on a redirect, and the PBX's web root redirects.
  $c = New-Object Net.Sockets.TcpClient
  try {
    $iar = $c.BeginConnect($h, $p, $null, $null)
    if ($iar.AsyncWaitHandle.WaitOne(4000)) {
      $c.EndConnect($iar)
      $s = $c.GetStream()
      $s.ReadTimeout = 4000
      $req = [Text.Encoding]::ASCII.GetBytes("HEAD / HTTP/1.0`r`nHost: ${h}`r`n`r`n")
      $s.Write($req, 0, $req.Length)
      $buf = New-Object byte[] 16
      $n = $s.Read($buf, 0, 16)
      if ($n -ge 5 -and [Text.Encoding]::ASCII.GetString($buf, 0, 5) -eq "HTTP/") { return "http" }
    }
  } catch { } finally { $c.Close() }
  return $null
}

Write-Host ""
Write-Host "LENDER NODE CHECK - $env:COMPUTERNAME - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ($((Get-TimeZone).Id))" -ForegroundColor White

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($admin) { Ok "elevated" } else { Warn "not elevated - install.ps1 needs an elevated PowerShell" }

# --- 1 Node -------------------------------------------------------------------
Head "1 - Node"
$nodeCmd = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCmd) {
  $v = (& node -v)
  $major = [int]($v.TrimStart("v").Split(".")[0])
  if ($major -ge 20) { Ok "node $v at $($nodeCmd.Source)" } else { No "node $v is too old: install Node 24 LTS (x64 MSI) from nodejs.org" }
} else { No "node is not installed: Node 24 LTS (x64 MSI) from nodejs.org, then open a NEW PowerShell" }

# --- 2 NSSM -------------------------------------------------------------------
Head "2 - Service wrapper (NSSM)"
$nssm = $null
$cmd = Get-Command nssm -ErrorAction SilentlyContinue
if ($cmd) { $nssm = $cmd.Source } elseif (Test-Path (Join-Path $PSScriptRoot "nssm.exe")) { $nssm = Join-Path $PSScriptRoot "nssm.exe" }
if ($nssm) { Ok "nssm at $nssm" } else { No "nssm not found: download nssm 2.24 from https://nssm.cc/download and put win64\nssm.exe in this folder" }

# --- 3 Tailscale --------------------------------------------------------------
Head "3 - Tailscale"
$ts = $null
$cmd = Get-Command tailscale -ErrorAction SilentlyContinue
if ($cmd) { $ts = $cmd.Source } elseif (Test-Path "C:\Program Files\Tailscale\tailscale.exe") { $ts = "C:\Program Files\Tailscale\tailscale.exe" }
if ($ts) {
  Ok "tailscale at $ts"
  $svc = Get-Service Tailscale -ErrorAction SilentlyContinue
  if ($svc) {
    if ($svc.StartType -eq "Automatic") { Ok "Tailscale service $($svc.Status), starts automatically" } else { Warn "Tailscale service start type is $($svc.StartType): set it to Automatic" }
  }
  $st = $null
  try { $st = (& $ts status --json 2>$null | Out-String) | ConvertFrom-Json } catch {}
  if ($st) {
    Note "this node: $($st.Self.HostName)  $($st.Self.TailscaleIPs -join ', ')  $($st.Self.DNSName)"
    $script:here = "$($st.Self.DNSName)".Split(".")[0]
    if ($script:here -eq $Node) { Ok "this is $Node" } else { No "this is '$($script:here)', not '$Node': run this on $Node (pass -Node $($script:here) only if this machine is deliberate)" }
    if ($st.Self.KeyExpiry) { Warn "node key expires $($st.Self.KeyExpiry): admin console -> Machines -> $($st.Self.HostName) -> Disable key expiry" } else { Ok "node key never expires" }
  }
  $prefs = $null
  try { $prefs = (& $ts debug prefs 2>$null | Out-String) | ConvertFrom-Json } catch {}
  if ($prefs) {
    if ($prefs.ForceDaemon) { Ok "unattended mode on: Tailscale keeps running with nobody signed in" } else { No "unattended mode OFF: Tailscale stops when the RDP user signs out (install.ps1 -Publish turns it on)" }
  }
  Note "funnel status now:"
  & $ts funnel status 2>&1 | ForEach-Object { Note "  $_" }
} else { No "tailscale not found" }

# --- 4 Ports and existing services --------------------------------------------
Head "4 - Local ports and services"
foreach ($p in 8787, 10001) {
  $l = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($l) {
    $proc = Get-Process -Id $l.OwningProcess -ErrorAction SilentlyContinue
    Warn "port $p is already in use by $($proc.ProcessName) (pid $($l.OwningProcess))"
  } else { Ok "port $p free" }
}
$old = Get-Service | Where-Object { $_.Name -match "Relay|Bridge|MicroEazy|LenderNode|ConnectDesk" }
if ($old) { $old | ForEach-Object { Note "service $($_.Name): $($_.Status), $($_.StartType)" } } else { Note "no relay or bridge services installed yet" }

# --- 5 SQL --------------------------------------------------------------------
Head "5 - Micromart's SQL Server (port $SqlPort)"
$sqlLanOk = Test-Tcp $SqlLan $SqlPort
$sqlTailOk = Test-Tcp $SqlTail $SqlPort
if ($sqlLanOk) { Ok "${SqlLan},$SqlPort reachable over the LAN" } else { Warn "${SqlLan},$SqlPort not reachable" }
if ($sqlTailOk) { Ok "${SqlTail},$SqlPort reachable over Tailscale" } else { Warn "${SqlTail},$SqlPort not reachable over Tailscale" }

# --- 6 PBX --------------------------------------------------------------------
Head "6 - Micromart's PBX API (port $PbxPort)"
$pbxLanKind = $null; $pbxWanKind = $null
if (Test-Tcp $PbxLan $PbxPort) { $pbxLanKind = Get-WebKind $PbxLan $PbxPort; Ok "${PbxLan}:$PbxPort open: $pbxLanKind" } else { Warn "${PbxLan}:$PbxPort not reachable from here" }
if (Test-Tcp $PbxWan $PbxPort) { $pbxWanKind = Get-WebKind $PbxWan $PbxPort; Ok "${PbxWan}:$PbxPort open: $pbxWanKind" } else { Warn "${PbxWan}:$PbxPort not reachable from here" }

# --- 7 Egress and clock -------------------------------------------------------
Head "7 - Public egress and clock"
$pub = $null
try { $pub = Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 10; Note "public egress: $pub (what the PBX sees when reached over the internet)" } catch { Warn "could not read the public egress address" }
try {
  $r = Invoke-WebRequest -Uri "https://www.microsoft.com" -Method Head -UseBasicParsing -TimeoutSec 10
  $skew = [math]::Round(((Get-Date).ToUniversalTime() - ([DateTime]::Parse($r.Headers["Date"])).ToUniversalTime()).TotalSeconds)
  if ([math]::Abs($skew) -le 30) { Ok "clock within $skew s of internet time" } else { No "clock is $skew s off: relay signatures allow 120 s, fix Windows Time first" }
} catch { Warn "could not compare the clock" }

# --- Verdict ------------------------------------------------------------------
Head "VERDICT - what goes in .env"
if ($script:here -and $script:here -ne $Node) { No "WRONG MACHINE: this is '$($script:here)', the kit is for '$Node'. install.ps1 will refuse here." }
if ($sqlLanOk) { Ok "SQL: Data Source=${SqlLan},$SqlPort  (LAN: no tailnet in the SQL path)" }
elseif ($sqlTailOk) { Ok "SQL: Data Source=${SqlTail},$SqlPort  (Tailscale)" }
else { No "SQL: no road from this server to Micromart's SQL Server - do not install the SQL relay here" }

$pbxHost = $null; $pbxKind = $null
if ($pbxLanKind) { $pbxHost = "${PbxLan}:$PbxPort"; $pbxKind = $pbxLanKind } elseif ($pbxWanKind) { $pbxHost = "${PbxWan}:$PbxPort"; $pbxKind = $pbxWanKind }
if ($pbxHost) {
  if ($pbxKind -like "https *") {
    $fp = $pbxKind.Split(" ")[1]
    Ok "PBX: PBX_ALLOW=$pbxHost"
    Ok "     PBX_TLS_PIN=$pbxHost=$fp"
    Ok "     ConnectDesk API address: https://$pbxHost/api/v1.1.0"
  } else {
    Ok "PBX: PBX_ALLOW=$pbxHost   (plain HTTP, no pin)"
    Ok "     ConnectDesk API address: http://$pbxHost/api/v1.1.0"
  }
  if ($pbxHost -like "$PbxWan*" -and $pub) { Note "if the PBX API keeps an allowed-IP list, it must include $pub" }
  else {
    $lan = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" -and $_.IPAddress -notlike "100.*" }).IPAddress -join ", "
    Note "if the PBX API keeps an allowed-IP list, it must include this server's LAN address ($lan)"
  }
} else { No "PBX: no road from this server to the PBX API - install the SQL relay only (-Sql), not the bridge" }
Write-Host ""
