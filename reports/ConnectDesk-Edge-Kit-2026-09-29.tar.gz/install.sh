#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Install the ConnectDesk media edge on a fresh Ubuntu 24.04 machine.
#
#   sudo ./install.sh <edge-dns-name> <org-slug> <edge-key> [letsencrypt-email]
#   sudo ./install.sh edge-fastdial.servicesuitecloud.com fastdial Xy…Zz ops@techcrast.co.ke
#
# Before running: the DNS name must point at this machine, and TCP 80 must be
# reachable from the internet for the certificate (see README for a LAN edge).
#
# INBOUND ONLY — the inbound line and Riri, no browser phones:
#
#   sudo ./install.sh --inbound-only fastdial Xy…Zz
#
# No DNS name, no certificate, no port open to the internet. The box only has
# to reach the PBX on the office network and ConnectDesk over HTTPS. Run the
# full install on the same machine later to add browser phones.
#
# Idempotent: safe to run again, e.g. after changing the org or the key.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
INBOUND_ONLY=0
if [ "${1:-}" = "--inbound-only" ]; then
  INBOUND_ONLY=1
  HOST=""
  ORG="${2:?org slug}"
  KEY="${3:?edge key from ConnectDesk}"
  EMAIL=""
else
  HOST="${1:?edge DNS name (or --inbound-only)}"
  ORG="${2:?org slug}"
  KEY="${3:?edge key from ConnectDesk}"
  EMAIL="${4:-ops@techcrast.co.ke}"
fi
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "── packages"
apt-get update -q
# Hold music for callers Riri keeps on the line (WaitExten's m option plays the default class).
if [ "$INBOUND_ONLY" = 1 ]; then
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q asterisk asterisk-moh-opsound-gsm curl ufw
else
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q asterisk asterisk-moh-opsound-gsm certbot curl ufw
fi

if [ "$INBOUND_ONLY" = 0 ]; then
echo "── certificate for $HOST"
if [ ! -d "/etc/letsencrypt/live/$HOST" ]; then
  systemctl stop asterisk || true
  certbot certonly --standalone -d "$HOST" -m "$EMAIL" --agree-tos -n
fi
install -d -o asterisk -g asterisk -m 750 /etc/asterisk/keys
install -m 640 -o asterisk -g asterisk "/etc/letsencrypt/live/$HOST/fullchain.pem" /etc/asterisk/keys/edge-fullchain.pem
install -m 640 -o asterisk -g asterisk "/etc/letsencrypt/live/$HOST/privkey.pem" /etc/asterisk/keys/edge-privkey.pem
install -d /etc/letsencrypt/renewal-hooks/deploy
cat > /etc/letsencrypt/renewal-hooks/deploy/connectdesk-edge.sh <<HOOK
#!/usr/bin/env bash
install -m 640 -o asterisk -g asterisk "/etc/letsencrypt/live/$HOST/fullchain.pem" /etc/asterisk/keys/edge-fullchain.pem
install -m 640 -o asterisk -g asterisk "/etc/letsencrypt/live/$HOST/privkey.pem" /etc/asterisk/keys/edge-privkey.pem
asterisk -rx "module reload http" >/dev/null || true
HOOK
chmod +x /etc/letsencrypt/renewal-hooks/deploy/connectdesk-edge.sh
fi

echo "── asterisk configuration"
stamp="$(date +%Y%m%d%H%M%S)"
for f in pjsip.conf http.conf rtp.conf extensions.conf; do
  [ -f "/etc/asterisk/$f" ] && cp "/etc/asterisk/$f" "/etc/asterisk/$f.before-connectdesk-$stamp"
  install -m 640 -o asterisk -g asterisk "$HERE/asterisk/$f" "/etc/asterisk/$f"
done
if [ "$INBOUND_ONLY" = 1 ]; then
  # No certificate, so no TLS: the HTTP server stays on localhost and carries nothing.
  cat > /etc/asterisk/http.conf <<'HTTP'
; ConnectDesk media edge, inbound only: no browser phones, so no secure WebSocket.
[general]
enabled=yes
bindaddr=127.0.0.1
bindport=8088
tlsenable=no
HTTP
  chown asterisk:asterisk /etc/asterisk/http.conf
  chmod 640 /etc/asterisk/http.conf
fi
for f in pjsip_connectdesk.conf extensions_connectdesk.conf; do
  [ -f "/etc/asterisk/$f" ] || install -m 640 -o asterisk -g asterisk /dev/null "/etc/asterisk/$f"
done
install -d -o asterisk -g asterisk /var/spool/asterisk/monitor/connectdesk

echo "── the sync"
cat > /etc/connectdesk-edge.env <<ENV
CONNECTDESK_URL=https://connectdesk.servicesuitecloud.com
ORG_SLUG=$ORG
EDGE_KEY=$KEY
ENV
chmod 600 /etc/connectdesk-edge.env
install -m 755 "$HERE/connectdesk-edge-sync" /usr/local/bin/connectdesk-edge-sync
install -m 644 "$HERE/systemd/connectdesk-edge-sync.service" /etc/systemd/system/
install -m 644 "$HERE/systemd/connectdesk-edge-sync.timer" /etc/systemd/system/
systemctl daemon-reload

echo "── firewall"
ufw allow OpenSSH >/dev/null
if [ "$INBOUND_ONLY" = 0 ]; then
  ufw allow 80/tcp >/dev/null      # certificate renewal
  ufw allow 8089/tcp >/dev/null    # SIP over secure WebSocket (browsers)
fi
ufw allow 10000:14999/udp >/dev/null  # media
ufw allow 5060/udp >/dev/null    # SIP to/from the PBX — narrow to the PBX's address if you can
ufw --force enable >/dev/null

echo "── start"
systemctl enable --now asterisk
systemctl enable --now connectdesk-edge-sync.timer
/usr/local/bin/connectdesk-edge-sync || true
sleep 3
asterisk -rx "pjsip show registrations" || true
echo
if [ "$INBOUND_ONLY" = 1 ]; then
  echo "Edge up (inbound only). Within a minute 'sudo asterisk -rx \"pjsip show registrations\"' should list reg-716 Registered."
  echo "If it lists nothing: ConnectDesk → Settings → Phone system needs the PBX SIP address, the inbound line and its password."
else
  echo "Edge up. In ConnectDesk → Settings → Connections set the media edge to wss://$HOST:8089/ws"
fi
