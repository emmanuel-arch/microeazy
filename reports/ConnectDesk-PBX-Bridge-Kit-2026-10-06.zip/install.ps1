# -----------------------------------------------------------------------------
# INSTALL THE CONNECTDESK PBX BRIDGE ON SERVICESUITE-IN - elevated PowerShell,
# in the kit folder (C:\ConnectDesk\pbx-bridge), after check.ps1:
#
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Install -Publish
#
#   -Install   .env (written from CallBox's own PBX settings when there is none),
#              folder permissions, and the service ConnectDeskPbxBridge
#              (node pbx-bridge.mjs on 127.0.0.1:10001, as LocalService)
#   -Publish   Tailscale Funnel https://servicesuite-in.<tailnet>.ts.net:10000
#              -> 127.0.0.1:10001. Only if 10000 is free or already the bridge's;
#              every other Funnel port (8443 is the SQL relay) is checked to be
#              exactly as it was. 443 is left to IIS.
#   -Remove    stop and delete the service; turn off the Funnel port that
#              forwards to the bridge. Nothing else is touched.
#   -FunnelPort  10000 (default), 8443 or 443 - the ports Funnel offers
#   -Nssm      path to nssm.exe if it is neither on PATH nor in this folder
#   -AsSystem  run the service as LocalSystem instead of LocalService
#   -PbxHost   the PBX this bridge serves (default Fastdial's, 197.248.179.183:8088)
#   -CallBoxSettings  the appsettings.json of the CallBox that drives that PBX
#              (Fastdial's: C:\inetpub\wwwroot\FastDial\appsettings.json). This
#              server holds several CallBoxes, one per client; without it, the
#              one whose HostSettings log in to -PbxHost is used.
#   -Force     install on a machine whose name or address is not servicesuite-in's
#
# Safe to run again. CallBox, IIS, the SQL relay and the Interchange engine are
# not stopped, restarted or reconfigured by anything here.
# -----------------------------------------------------------------------------
param(
  [switch]$Install,
  [switch]$Publish,
  [switch]$Remove,
  [string]$Nssm = "",
  [switch]$AsSystem,
  [string]$Node = "servicesuite-in",
  [string]$Egress = "213.148.17.228",
  [string]$PbxHost = "197.248.179.183:8088",
  [string]$CallBoxSettings = "",
  # Funnel offers 443, 8443 and 10000. 443 stays IIS's and 8443 is the SQL relay.
  [ValidateSet("443", "8443", "10000")][string]$FunnelPort = "10000",
  [switch]$Force
)

# Continue, not Stop: under Stop, Windows PowerShell 5.1 turns any line a native
# tool (nssm, tailscale) writes to stderr into a terminating error. Failures that
# matter are checked explicitly.
$ErrorActionPreference = "Continue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
. (Join-Path $PSScriptRoot "common.ps1")

$root = $PSScriptRoot
$SVC = "ConnectDeskPbxBridge"
$LOCAL = "http://127.0.0.1:10001"
function Die($s) { Write-Host "  [STOP] $s" -ForegroundColor Red; Write-Host ""; exit 1 }

if (-not (Test-Admin)) { Die "run this from an elevated PowerShell (Run as administrator)" }
if (-not ($Install -or $Publish -or $Remove)) { Die "nothing to do: pass -Install and -Publish (or -Remove). Run check.ps1 first." }
$ts = Get-TailscaleExe
$nssmExe = Get-NssmExe $root $Nssm

function Remove-Svc {
  if (Get-Service $SVC -ErrorAction SilentlyContinue) {
    if ($nssmExe) { & $nssmExe stop $SVC 2>&1 | Out-Null; & $nssmExe remove $SVC confirm 2>&1 | Out-Null }
    else { Stop-Service $SVC -Force -ErrorAction SilentlyContinue; sc.exe delete $SVC | Out-Null }
    Ok "removed service $SVC"
  }
}

# --- Remove -------------------------------------------------------------------
if ($Remove) {
  Head "Removing the ConnectDesk PBX bridge"
  Remove-Svc
  if ($ts) {
    $map = Get-ServeMap $ts
    $mine = @($map.Keys | Where-Object { $map[$_] -eq $LOCAL })
    foreach ($p in $mine) { & $ts funnel --https=$p off 2>&1 | Out-Null; Ok "Funnel $p turned off" }
    if (-not $mine.Count) { Note "no Funnel port forwards to the bridge" }
    & $ts serve status
  }
  Write-Host ""
  Write-Host "ConnectDesk: clear the Telephony bridge URL (Settings -> Phone system) for every organisation that used it." -ForegroundColor Yellow
  Write-Host ""
  exit 0
}

# --- The right machine --------------------------------------------------------
Head "This machine"
if (-not $ts) { Die "tailscale.exe not found" }
$self = Get-TailnetSelf $ts
$here = $null
if ($self) { $here = "$($self.DNSName)".Split(".")[0] }
if ($here -ne $Node) { if ($Force) { Warn "this is '$here', not '$Node' (-Force)" } else { Die "this is '$here' on the tailnet, not '$Node'. Open the RDP session on $Node." } }
else { Ok "this is $Node" }
$pub = Get-PublicIp
if ($pub -ne $Egress) {
  if ($Force) { Warn "egress is '$pub', not $Egress (-Force)" }
  else { Die "this server reaches the internet from '$pub', not ${Egress}. The bridge exists to call the PBX from CallBox's address." }
} else { Ok "egress $pub (CallBox's address)" }
if ($root -like "C:\Users\*") { Die "the kit is in a user profile ($root). Move it to C:\ConnectDesk\pbx-bridge and run it from there." }

# --- .env ---------------------------------------------------------------------
$envFile = Join-Path $root ".env"
if ($Install) {
  Head ".env"
  # The CallBox on this server that logs in to Fastdial's PBX. There are several
  # CallBoxes here, one per client, each with its own PBX.
  $sel = Select-CallBox @(Get-CallBoxCopies) $CallBoxSettings $PbxHost
  if ($sel.Error) {
    if ($sel.Conflict) { Show-Conflict $sel.Conflict }
    Die $sel.Error
  }
  $hs = $sel.Copy.Hs
  $file = $sel.Copy.File
  Ok "Fastdial's CallBox: $file"
  foreach ($o in $sel.Same) { Note "same PBX login and report target: $($o.File)" }
  if (-not (Test-Path $envFile)) {
    foreach ($k in "username", "password", "port", "url", "urltag", "version") { if (-not $hs[$k]) { Die "CallBox's HostSettings has no '$k'" } }
    $target = Get-PbxTarget $hs
    $bytes = New-Object byte[] 32
    [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $secret = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
    $lines = @(
      "# Written by install.ps1 on $(Get-Date -Format 'yyyy-MM-dd HH:mm') from $file. See .env.example.",
      "BRIDGE_SECRET=$secret",
      "PBX_ALLOW=$($target.HostPort)",
      "PBX_REPORT_PORT=$($hs['port'])",
      "PBX_REPORT_URL=$($hs['url'])",
      "PBX_REPORT_URLTAG=$($hs['urltag'])",
      "PBX_REPORT_VERSION=$($hs['version'])",
      "PBX_LOGIN_SHA256=$(Get-Sha256Hex ("$($hs['username']):$($hs['password'])"))",
      "BRIDGE_PORT=10001",
      "BRIDGE_HOST=127.0.0.1",
      "BRIDGE_SESSION=shared"
    )
    Set-Content -Path $envFile -Value $lines -Encoding ASCII
    Ok "wrote .env from CallBox's settings ($file)"
  } else { Ok ".env exists: kept" }
  $cfg = Read-DotEnv $envFile
  if (-not $cfg["BRIDGE_SECRET"] -or $cfg["BRIDGE_SECRET"].Length -lt 24) { Die "BRIDGE_SECRET must be at least 24 characters" }
  if ($cfg["PBX_ALLOW"] -ne $PbxHost) { Die "PBX_ALLOW is '$($cfg["PBX_ALLOW"])', not $PbxHost (Fastdial's PBX): fix .env or delete it to have it written again" }
  foreach ($k in "PBX_REPORT_PORT", "PBX_REPORT_URL", "PBX_REPORT_URLTAG", "PBX_REPORT_VERSION") { if (-not $cfg[$k]) { Die "$k is empty: on CallBox's address every login must carry CallBox's report target" } }
  if ($cfg["PBX_LOGIN_SHA256"] -notmatch '^[0-9a-f]{64}$') { Die "PBX_LOGIN_SHA256 must be 64 hex characters" }
  if ($cfg["BRIDGE_SESSION"] -eq "passthrough") { Die "BRIDGE_SESSION=passthrough would give every ConnectDesk server its own PBX session again" }
  if ($cfg["CONNECTDESK_URL"] -or $cfg["CRON_SECRET"]) { Warn "CONNECTDESK_URL/CRON_SECRET set: this bridge will also tick EVERY organisation's floor each minute" }
  if ($hs) {
    if (-not ("$($hs['url'])" -like "$Egress*")) { Warn "this CallBox's report url is '$($hs['url'])', not on $Egress" }
    $same = ($cfg["PBX_REPORT_PORT"] -eq $hs["port"]) -and ($cfg["PBX_REPORT_URL"] -eq $hs["url"]) -and ($cfg["PBX_REPORT_URLTAG"] -eq $hs["urltag"]) -and ($cfg["PBX_REPORT_VERSION"] -eq $hs["version"])
    if ($same) { Ok "report target matches CallBox's: $($cfg['PBX_REPORT_URL'])" } else { Die "PBX_REPORT_* in .env differ from CallBox's live HostSettings ($file): fix .env or delete it to have it written again" }
    if ($cfg["PBX_LOGIN_SHA256"] -eq (Get-Sha256Hex ("$($hs['username']):$($hs['password'])"))) { Ok "API user matches CallBox's" } else { Die "PBX_LOGIN_SHA256 is not CallBox's API user and password: delete .env to have it written again" }
  }
}

# --- Service ------------------------------------------------------------------
if ($Install) {
  Head "Service"
  $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
  if (-not $nodeCmd) { Die "node is not on PATH, or this PowerShell was opened before it was installed - open a new one" }
  if (-not $nssmExe) { Die "nssm.exe not found: put win64\nssm.exe (nssm 2.24) in this folder, or pass -Nssm" }
  if (-not (Test-Path (Join-Path $root "pbx-bridge.mjs"))) { Die "pbx-bridge.mjs is missing: unzip the whole kit here" }
  $who = Get-Listener 10001
  $mine = Get-Service $SVC -ErrorAction SilentlyContinue
  if ($who -and -not ($mine -and $mine.Status -eq "Running")) { Die "port 10001 is in use by $who" }

  $logs = Join-Path $root "logs"
  if (-not (Test-Path $logs)) { New-Item -ItemType Directory $logs | Out-Null }
  # *S-1-5-32-544 Administrators, *S-1-5-18 SYSTEM, *S-1-5-19 LOCAL SERVICE. The files inherit it.
  icacls $root /inheritance:r /grant:r "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-19:(OI)(CI)RX" /C /Q 2>&1 | Out-Null
  if ($LASTEXITCODE -ne 0) { Die "could not set permissions on $root" }
  icacls $logs /grant "*S-1-5-19:(OI)(CI)M" /C /Q 2>&1 | Out-Null
  icacls $envFile /inheritance:r /grant:r "*S-1-5-32-544:F" "*S-1-5-18:F" "*S-1-5-19:R" /C /Q 2>&1 | Out-Null
  if ($LASTEXITCODE -ne 0) { Die "could not lock down .env" }
  Ok "${root}: Administrators, SYSTEM and LocalService (read) only; .env readable by those three"

  Remove-Svc
  & $nssmExe install $SVC $nodeCmd.Source "pbx-bridge.mjs" 2>&1 | Out-Null
  if ($LASTEXITCODE -ne 0) { Die "nssm could not install $SVC" }
  & $nssmExe set $SVC AppDirectory $root | Out-Null
  & $nssmExe set $SVC DisplayName "ConnectDesk - PBX bridge" | Out-Null
  & $nssmExe set $SVC Description "One PBX session for every ConnectDesk server, from CallBox's address. Kit in $root, see README.md." | Out-Null
  & $nssmExe set $SVC Start SERVICE_AUTO_START | Out-Null
  & $nssmExe set $SVC AppStdout (Join-Path $logs "$SVC.log") | Out-Null
  & $nssmExe set $SVC AppStderr (Join-Path $logs "$SVC.log") | Out-Null
  & $nssmExe set $SVC AppRotateFiles 1 | Out-Null
  & $nssmExe set $SVC AppRotateOnline 1 | Out-Null
  & $nssmExe set $SVC AppRotateBytes 10485760 | Out-Null
  & $nssmExe set $SVC AppExit Default Restart | Out-Null
  & $nssmExe set $SVC AppRestartDelay 5000 | Out-Null
  if (-not $AsSystem) {
    # Through WMI: Windows PowerShell 5.1 drops the empty password argument sc.exe needs.
    $w = Get-CimInstance Win32_Service -Filter "Name='$SVC'"
    $r = Invoke-CimMethod -InputObject $w -MethodName Change -Arguments @{ StartName = "NT AUTHORITY\LocalService"; StartPassword = "" }
    if ($r.ReturnValue -ne 0) { Die "could not set $SVC to run as LocalService (WMI code $($r.ReturnValue)); rerun with -AsSystem" }
  }
  sc.exe failure $SVC reset= 86400 actions= restart/5000/restart/5000/restart/30000 | Out-Null
  & $nssmExe start $SVC 2>&1 | Out-Null

  $h = $null
  for ($i = 0; $i -lt 20; $i++) {
    try { $h = Invoke-RestMethod -Uri "$LOCAL/health" -TimeoutSec 3; if ($h.ok) { break } } catch {}
    Start-Sleep -Milliseconds 1500
  }
  if (-not ($h -and $h.ok)) { Die "the bridge did not answer on $LOCAL/health within 30 s - read logs\$SVC.log" }
  Ok "service $SVC running: $($h.mode) session, report target $($h.reportTarget), API user $($h.apiUser), PBX $($h.allow -join ', ')"
}

# --- Publish ------------------------------------------------------------------
$bridgeUrl = "https://$("$($self.DNSName)".TrimEnd('.'))"
if ($FunnelPort -ne "443") { $bridgeUrl += ":$FunnelPort" }
if ($Publish) {
  Head "Tailscale Funnel $FunnelPort"
  $before = Get-ServeMap $ts
  if ($before.ContainsKey($FunnelPort) -and $before[$FunnelPort] -ne $LOCAL) { Die "Funnel $FunnelPort already forwards to '$($before[$FunnelPort])'. Not touching it." }
  $prefs = $null
  try { $prefs = (& $ts debug prefs 2>$null | Out-String) | ConvertFrom-Json } catch {}
  if ($prefs -and -not $prefs.ForceDaemon) {
    & $ts set --unattended=true 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { Ok "unattended mode turned on (Tailscale keeps running with nobody signed in)" } else { Warn "could not turn on unattended mode: Tailscale tray icon -> Preferences -> Run unattended" }
  }
  if ($before[$FunnelPort] -ne $LOCAL) {
    & $ts funnel --bg --https=$FunnelPort $LOCAL
    if ($LASTEXITCODE -ne 0) { Die "Funnel refused $FunnelPort - is Funnel allowed for this node (admin console, Access controls)?" }
  }
  $after = Get-ServeMap $ts
  if ($after[$FunnelPort] -eq $LOCAL) { Ok "$bridgeUrl -> $LOCAL" } else { No "$FunnelPort does not forward to the bridge after publishing: $($after[$FunnelPort])" }
  foreach ($p in $before.Keys) {
    if ($p -eq $FunnelPort) { continue }
    if ($after[$p] -eq $before[$p]) { Ok "Funnel :$p unchanged ($($before[$p]))" }
    else { No "Funnel :$p CHANGED: was '$($before[$p])', now '$($after[$p])' - restore it: tailscale funnel --bg --https=$p $($before[$p])" }
  }
  & $ts serve status
}

# --- What ConnectDesk needs ---------------------------------------------------
if ($Publish -or $Install) {
  $cfg = Read-DotEnv $envFile
  Head "ConnectDesk: Settings -> Connections & seats -> Phone system -> Telephony bridge"
  Write-Host "  URL     $bridgeUrl" -ForegroundColor Cyan
  Write-Host "  Secret  $($cfg['BRIDGE_SECRET'])" -ForegroundColor Cyan
  Note "Fastdial first: Save, then Test. Then Mular Credit (it shares this PBX). The secret is also in .env."
}
Write-Host ""
