# -----------------------------------------------------------------------------
# CONNECTDESK PBX BRIDGE ON SERVICESUITE-IN - CHECK. Run it FIRST, on
# servicesuite-in, in an elevated PowerShell, in the kit folder:
#
#   powershell -ExecutionPolicy Bypass -File check.ps1 -SessionTest
#
# It answers what install.ps1 depends on: that this is servicesuite-in and
# reaches the internet from 213.148.17.228 (the address CallBox calls the PBX
# from); Node and NSSM; Tailscale and its Funnel ports (10000 must be free for
# the bridge; 8443 is the SQL relay and 443 stays IIS's, both left alone);
# port 10001; which CallBox on this server drives Fastdial's PBX, and its PBX
# settings, from which install.ps1 writes .env; and the PBX API.
#
# Read-only, except -SessionTest: it logs in to Fastdial's PBX twice, exactly as
# that CallBox does before every click (same API user, same event-report target,
# same address, so CallBox's call feed does not move), then asks for the
# extension list with each token. It answers one question - does a second login
# from this address cancel the first token? It stops at the first login that is
# refused or unanswered (five refusals in a row lock the API user), it never
# logs out, and it never runs against any PBX but -PbxHost.
# -----------------------------------------------------------------------------
param(
  [string]$Node = "servicesuite-in",
  [string]$Egress = "213.148.17.228",
  [string]$PbxHost = "197.248.179.183:8088",
  [string]$CallBoxSettings = "",
  # Funnel offers 443, 8443 and 10000. 443 stays IIS's and 8443 is the SQL relay.
  [ValidateSet("443", "8443", "10000")][string]$FunnelPort = "10000",
  [switch]$SessionTest
)

$ErrorActionPreference = "Continue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
. (Join-Path $PSScriptRoot "common.ps1")

Write-Host ""
Write-Host "CONNECTDESK PBX BRIDGE - CHECK - $env:COMPUTERNAME - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor White
$fails = 0
if (Test-Admin) { Ok "elevated" } else { Warn "not elevated - install.ps1 needs an elevated PowerShell" }

# --- 1 This machine -----------------------------------------------------------
Head "1 - This machine"
$ts = Get-TailscaleExe
$self = $null
if ($ts) { $self = Get-TailnetSelf $ts }
$here = $null
if ($self) { $here = "$($self.DNSName)".Split(".")[0] }
if ($here -eq $Node) { Ok "this is $Node on the tailnet ($("$($self.DNSName)".TrimEnd('.')))" }
else { No "this is '$here' on the tailnet, not '$Node'"; $fails++ }
$pub = Get-PublicIp
if ($pub -eq $Egress) { Ok "reaches the internet from $pub - the address CallBox calls the PBX from" }
elseif ($pub) { No "reaches the internet from $pub, not ${Egress}: the PBX would see the bridge as a second application server"; $fails++ }
else { Warn "could not read the public egress address (https://api.ipify.org)" }
try {
  $r = Invoke-WebRequest -Uri "https://www.microsoft.com" -Method Head -UseBasicParsing -TimeoutSec 10
  $skew = [math]::Round(((Get-Date).ToUniversalTime() - ([DateTime]::Parse($r.Headers["Date"])).ToUniversalTime()).TotalSeconds)
  if ([math]::Abs($skew) -le 20) { Ok "clock within $skew s of internet time" } else { No "clock is $skew s off: ConnectDesk's signatures are valid for 60 s - fix Windows Time first"; $fails++ }
} catch { Warn "could not compare the clock with internet time" }

# --- 2 Node and NSSM ----------------------------------------------------------
Head "2 - Node and NSSM"
$nodeCmd = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCmd) {
  $v = (& node -v)
  $major = [int]("$v".TrimStart("v").Split(".")[0])
  if ($major -ge 20) { Ok "node $v at $($nodeCmd.Source)" } else { No "node $v is too old (20 or later)"; $fails++ }
} else { No "node is not on PATH (open a new PowerShell after installing it)"; $fails++ }
$nssm = Get-NssmExe $PSScriptRoot ""
if ($nssm) { Ok "nssm at $nssm" } else { No "nssm not found on PATH, in this folder, or behind any service: put win64\nssm.exe (nssm 2.24, https://nssm.cc/download) in this folder"; $fails++ }

# --- 3 Tailscale --------------------------------------------------------------
Head "3 - Tailscale"
if ($ts) {
  $svc = Get-Service Tailscale -ErrorAction SilentlyContinue
  if ($svc -and $svc.StartType -eq "Automatic") { Ok "Tailscale service $($svc.Status), starts automatically" } elseif ($svc) { Warn "Tailscale service start type is $($svc.StartType)" }
  $prefs = $null
  try { $prefs = (& $ts debug prefs 2>$null | Out-String) | ConvertFrom-Json } catch {}
  if ($prefs) { if ($prefs.ForceDaemon) { Ok "unattended mode on" } else { Warn "unattended mode OFF: signing out of RDP takes this node (SQL relay, bridge) off the internet - install.ps1 -Publish turns it on" } }
  if ($self -and $self.KeyExpiry) { Warn "node key expires $($self.KeyExpiry): admin console -> Machines -> $($self.HostName) -> Disable key expiry" }
  $map = Get-ServeMap $ts
  foreach ($p in ($map.Keys | Sort-Object)) {
    $what = " (left alone)"
    if ($p -eq $FunnelPort) { $what = "" } elseif ($p -eq "8443") { $what = " (SQL relay - left alone)" }
    Note "funnel/serve :$p -> $($map[$p])$what"
  }
  if (-not $map.ContainsKey($FunnelPort)) { Ok "Funnel $FunnelPort is free for the bridge" }
  elseif ($map[$FunnelPort] -eq "http://127.0.0.1:10001") { Ok "Funnel $FunnelPort already forwards to the bridge" }
  else { No "Funnel $FunnelPort already forwards to '$($map[$FunnelPort])': the bridge will not take it"; $fails++ }
} else { No "tailscale.exe not found"; $fails++ }

# --- 4 Local port -------------------------------------------------------------
Head "4 - Local port 10001"
$who = Get-Listener 10001
$svcB = Get-Service ConnectDeskPbxBridge -ErrorAction SilentlyContinue
if (-not $who) { Ok "port 10001 free" }
elseif ($svcB -and $svcB.Status -eq "Running") { Ok "port 10001: the bridge is already running ($who)" }
else { No "port 10001 is in use by $who"; $fails++ }
Get-Service | Where-Object { $_.Name -match "Relay|Bridge|Interchange|MicroEazy|ConnectDesk" } | ForEach-Object { Note "service $($_.Name): $($_.Status), $($_.StartType)" }

# --- 5 CallBox ----------------------------------------------------------------
Head "5 - The CallBox that drives Fastdial's PBX ($PbxHost)"
$copies = @(Get-CallBoxCopies)
foreach ($c in $copies) {
  $state = "isPbxConfigured=0, never logs in"
  if ($c.LogsIn) { $state = "logs in" }
  Note ("{0,-58} PBX {1,-22} {2}" -f $c.File, $c.Pbx, $state)
}
$sel = Select-CallBox $copies $CallBoxSettings $PbxHost
$hs = $null; $target = $null
if ($sel.Error) {
  No $sel.Error; $fails++
  if ($sel.Conflict) { Show-Conflict $sel.Conflict }
} else {
  $hs = $sel.Copy.Hs
  Ok "Fastdial's CallBox: $($sel.Copy.File)"
  foreach ($o in $sel.Same) { Note "same PBX login and report target: $($o.File)" }
  foreach ($k in "ApiUrl", "BaseUrl", "username", "port", "url", "urltag", "version", "isPbxConfigured") { Note ("{0,-16}{1}" -f $k, $hs[$k]) }
  if ($hs["password"]) { Note "password        (present, not shown)" } else { No "HostSettings has no password"; $fails++ }
  $target = Get-PbxTarget $hs
  Ok "PBX API: $($target.ApiBase)"
  if ("$($hs["url"])" -like "$Egress*") { Ok "its PBX event reports go to this server ($($hs["url"]))" } else { Warn "its report url is '$($hs["url"])', not on $Egress - tell the developer before installing" }
  if (-not ($hs["port"] -and $hs["url"] -and $hs["urltag"] -and $hs["version"])) { No "port, url, urltag and version must all be set"; $fails++ }
}

# --- 6 PBX API ----------------------------------------------------------------
Head "6 - The PBX API (no login: a token-less request the PBX refuses)"
if ($target) {
  for ($i = 1; $i -le 3; $i++) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $r = Invoke-PbxPost "$($target.ApiBase)/extensionlist/query?token=none" @{} 20
    $ms = $sw.ElapsedMilliseconds
    if ($r -and "$($r.errno)" -eq "20004") { Ok "answered in $ms ms (errno 20004, as expected without a token)" }
    elseif ($r) { Warn "answered in $ms ms: $($r | ConvertTo-Json -Compress)" }
    else { No "no answer within 20 s"; $fails++ }
    Start-Sleep -Milliseconds 700
  }
} else { Note "skipped: no CallBox for $PbxHost was chosen" }

# --- 7 Session test -----------------------------------------------------------
$verdict = $null
if ($SessionTest) {
  Head "7 - Session test: does a second login from this address cancel the first token?"
  if (-not ($hs -and $target -and $hs["password"] -and $target.HostPort -eq $PbxHost)) { $verdict = "not run"; Note "skipped: Fastdial's CallBox settings were not read" }
  else {
    $login = [ordered]@{ username = $hs["username"]; password = $hs["password"]; port = $hs["port"]; version = $hs["version"]; url = $hs["url"]; urltag = $hs["urltag"] }
    $kept = 0; $cancelled = 0; $runs = 0
    for ($i = 1; $i -le 3; $i++) {
      $a = Invoke-PbxPost "$($target.ApiBase)/login" $login
      if (-not $a) { No "login: no answer from the PBX - test stopped"; break }
      if ("$($a.status)" -ne "Success") { No "login refused (errno $($a.errno)) - test stopped, so the API user is not locked"; break }
      $b = Invoke-PbxPost "$($target.ApiBase)/login" $login
      if (-not $b) { No "second login: no answer from the PBX - test stopped"; break }
      if ("$($b.status)" -ne "Success") { No "second login refused (errno $($b.errno)) - test stopped"; break }
      $ra = Invoke-PbxPost "$($target.ApiBase)/extensionlist/query?token=$($a.token)" @{}
      $rb = Invoke-PbxPost "$($target.ApiBase)/extensionlist/query?token=$($b.token)" @{}
      $runs++
      Note "run ${i}: first token -> $("$($ra.status) $($ra.errno)".Trim()); second token -> $("$($rb.status) $($rb.errno)".Trim())"
      if ("$($ra.status)" -eq "Success") { $kept++ } elseif ("$($ra.errno)" -eq "20004" -and "$($rb.status)" -eq "Success") { $cancelled++ }
      Start-Sleep -Seconds 2
    }
    if ($kept -gt 0) { $verdict = "independent"; Ok "INDEPENDENT: a second login from this address leaves the first token working. CallBox and the bridge never disturb each other." }
    elseif ($cancelled -gt 0) { $verdict = "per-address"; Warn "ONE TOKEN PER ADDRESS: each login cancels the one before it. The bridge logs in again after CallBox clicks and retries ConnectDesk's call; a CallBox click can fail only if the bridge's login lands in the moment between CallBox's login and its dial." }
    elseif ($runs -eq 0) { $verdict = "not run"; Warn "the session test did not run (see above)" }
    else { $verdict = "inconclusive"; Warn "INCONCLUSIVE (a CallBox click probably landed between the steps) - run the test again" }
  }
}

# --- Verdict ------------------------------------------------------------------
Head "VERDICT"
if ($fails -gt 0) { No "$fails check(s) failed - fix them first; install.ps1 refuses until they pass." }
else {
  $how = "powershell -ExecutionPolicy Bypass -File install.ps1 -Install -Publish"
  if ($CallBoxSettings) { $how += " -CallBoxSettings `"$CallBoxSettings`"" }
  if ($FunnelPort -ne "10000") { $how += " -FunnelPort $FunnelPort" }
  Ok "ready: $how"
  Note "the bridge will call $PbxHost only, with the API user and report target of $($sel.Copy.File)"
  $bridgeUrl = "https://$("$($self.DNSName)".TrimEnd('.'))"
  if ($FunnelPort -ne "443") { $bridgeUrl += ":$FunnelPort" }
  Note "it will be published at $bridgeUrl (Funnel $FunnelPort)"
}
if ($verdict) { Note "session test: $verdict (tell the developer)" }
Write-Host ""
