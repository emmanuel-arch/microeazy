// ─────────────────────────────────────────────────────────────────────────────
// THE TELEPHONY BRIDGE — the one address ConnectDesk reaches a PBX from, and the
// floor's minute-by-minute scheduler. No dependencies; Node 20+.
//
// 1. POST /pbx       ConnectDesk runs on Vercel, whose addresses change. Each
//                    request is HMAC-signed by ConnectDesk (TelephonyConfig
//                    bridgeSecret) and may only go to a PBX on PBX_ALLOW. A PBX
//                    whose API only accepts listed IPs (Yeastar error 20015)
//                    accepts this machine instead.
//    POST /pbx-file  a call recording the PBX serves by GET, streamed back.
//    GET  /health    what the bridge is doing, and how fast the PBX answers.
//
// ── ONE PBX LOGIN FOR EVERY CONNECTDESK SERVER (BRIDGE_SESSION=shared) ──────
// A Yeastar S-series sends every event report once per API session. CallBox
// logs in from one address before every click and never caused a duplicate;
// ConnectDesk, logging in from Vercel's changing addresses, left Fastdial's PBX
// posting each event to CallBox's receiver up to 38 times, and its API slowed
// and its call engine restarted as the copies grew (6 Oct 2026). So the bridge
// holds the login:
//   · a login is answered with the bridge's live token when it has one for the
//     same credentials; the PBX is not asked again;
//   · every API call leaves with the bridge's current token, but only for a
//     caller holding a token the bridge handed out — which takes a login with
//     the PBX's own credentials. Any other token is answered 20004 and the
//     ConnectDesk server logs in through the bridge: no server's own session is
//     kept alive from here, and the bridge secret alone places no call;
//   · a token the PBX has dropped (20004/20005/20006) is replaced by one login,
//     shared by every request waiting on it, after a short pause, and the call
//     is retried while ConnectDesk is still waiting. A call that got no answer
//     is never repeated: the PBX may have acted on it;
//   · extensionlist/query and outbound/query, which every phone polls, are
//     shared for 2 s / 1.5 s instead of asked once per ConnectDesk server.
// BRIDGE_SESSION=passthrough forwards everything as it is (the old behaviour).
//
// ── SHARING AN ADDRESS WITH THE PBX'S OTHER CLIENT ───────────────────────────
// On servicesuite-in (213.148.17.228) the bridge shares its address with
// CallBox, which logs in to the same PBX with the same API user:
//   · PBX_REPORT_PORT/_URL/_URLTAG/_VERSION: a login carrying any other event
//     report target is refused here, before the PBX sees it — it would move
//     CallBox's live call feed;
//   · PBX_LOGIN_SHA256 (sha256 of "user:md5password"): any other API user or
//     password is refused here — five failed logins lock the API user for ten
//     minutes, CallBox's included;
//   · logout and heartbeat are never forwarded: either could drop or re-point
//     the report entry CallBox depends on;
//   · a login the PBX refuses is not repeated with the same credentials for
//     three minutes.
//
// 2. The floor's scheduler: every minute it calls ConnectDesk's
//    /api/cron/desk-floor (CONNECTDESK_URL + CRON_SECRET), so 08:00 starts the
//    dialler and a break turns red even when no screen is open.
//
// 3. A PBX on a private LAN (Micromart's S50, 192.168.1.150, reached over the
//    lender's VPN): run the bridge on a machine connected to that VPN. Its API
//    is HTTPS with the certificate the PBX shipped with, which no public CA
//    signs — so it is trusted by fingerprint, per host, in PBX_TLS_PIN:
//
//   PBX_ALLOW=192.168.1.150:8088  PBX_TLS_PIN=192.168.1.150:8088=AB:CD:…
//
//   BRIDGE_SECRET=…  PBX_ALLOW=197.248.179.183:8088  BRIDGE_PORT=10001  node server.mjs
// ─────────────────────────────────────────────────────────────────────────────
import http from "node:http";
import https from "node:https";
import tls from "node:tls";
import net from "node:net";
import crypto from "node:crypto";
import fs from "node:fs";

// A `.env` beside this file, when there is one (a lender node keeps the SQL
// relay's settings and these in one file). The service's own environment wins.
try {
  for (const line of fs.readFileSync(new URL("./.env", import.meta.url), "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(["'])(.*)\1$/, "$2");
  }
} catch { /* no .env: the environment is the configuration */ }

const VERSION = "2026-10-06.2";
const env = (k) => (process.env[k] || "").trim();
const num = (k, d, lo, hi) => { const v = env(k); const n = Number(v); return v && Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };

const PORT = Number(process.env.BRIDGE_PORT || process.env.PORT || 10001);
const HOST = env("BRIDGE_HOST") || "127.0.0.1";
const SECRET = process.env.BRIDGE_SECRET || "";
const ALLOW = new Set((process.env.PBX_ALLOW || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean));
const CONNECTDESK = env("CONNECTDESK_URL").replace(/\/+$/, "");
const CRON_SECRET = env("CRON_SECRET");
const MODE = /^passthrough$/i.test(env("BRIDGE_SESSION")) ? "passthrough" : "shared";
/** The local address PBX calls leave from, when this machine has more than one. */
const SOURCE_IP = env("BRIDGE_SOURCE_IP");
/** ConnectDesk gives up on a PBX request at 9 s; the bridge answers before that. */
const BUDGET_MS = num("BRIDGE_BUDGET_MS", 8500, 2000, 30_000);
const SETTLE_MS = num("BRIDGE_RELOGIN_SETTLE_MS", 300, 0, 3000);
const READ_CACHE = env("BRIDGE_READ_CACHE") !== "0";
const REPORT = { port: env("PBX_REPORT_PORT"), url: env("PBX_REPORT_URL"), urltag: env("PBX_REPORT_URLTAG"), version: env("PBX_REPORT_VERSION") };
const GUARDED = Object.keys(REPORT).filter((k) => REPORT[k]);
const LOGIN_SHA = env("PBX_LOGIN_SHA256").toLowerCase();

const hex = (s) => String(s || "").replace(/[^0-9a-f]/gi, "").toUpperCase();
/** host:port → the SHA-256 fingerprint its certificate must have. Never "accept any certificate". */
const PINS = new Map(
  (process.env.PBX_TLS_PIN || "").split(",").map((s) => s.trim()).filter(Boolean).map((s) => {
    const i = s.lastIndexOf("=");
    return [s.slice(0, i).trim().toLowerCase(), hex(s.slice(i + 1))];
  }),
);

if (!SECRET || SECRET.length < 24) { console.error("BRIDGE_SECRET (24+ chars) is required"); process.exit(1); }
if (!ALLOW.size) { console.error("PBX_ALLOW (host:port list) is required"); process.exit(1); }
if (SOURCE_IP && !net.isIP(SOURCE_IP)) { console.error(`BRIDGE_SOURCE_IP "${SOURCE_IP}" is not an IP address`); process.exit(1); }
if (LOGIN_SHA && !/^[0-9a-f]{64}$/.test(LOGIN_SHA)) { console.error("PBX_LOGIN_SHA256 must be 64 hex characters"); process.exit(1); }

const log = (...a) => console.log(new Date().toISOString(), ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const from = SOURCE_IP ? { localAddress: SOURCE_IP } : {};

/**
 * A request to a PBX. Plain HTTP for Fastdial. For https, node:https on a
 * socket whose certificate has already been checked against the pin, so not one
 * byte of the request (the API password included) goes to anything else. An
 * unpinned https host is refused with the fingerprint it presented, to be
 * compared with the PBX's own certificate screen and then pinned.
 */
function pbxFetch(url, { method = "GET", headers = {}, body, timeoutMs }) {
  const signal = AbortSignal.timeout(Math.max(1, timeoutMs));
  const wrap = (res) => ({
    status: res.statusCode ?? 502,
    headers: { get: (n) => { const v = res.headers[n.toLowerCase()]; return Array.isArray(v) ? v.join(", ") : v ?? null; } },
    body: res,
    text: async () => {
      let t = "";
      res.setEncoding("utf8");
      for await (const c of res) { t += c; if (t.length > 4_000_000) throw new Error("the PBX's answer is too large"); }
      return t;
    },
  });
  return new Promise((resolve, reject) => {
    let req;
    if (url.protocol !== "https:") {
      req = http.request(url, { method, headers, signal, agent: false, ...from }, (res) => resolve(wrap(res)));
    } else {
      const pin = PINS.get(url.host.toLowerCase());
      req = https.request(url, {
        method, headers, signal,
        createConnection: (_opts, done) => {
          const s = tls.connect({ host: url.hostname, port: Number(url.port || 443), rejectUnauthorized: false, ...from });
          s.setTimeout(timeoutMs, () => s.destroy(new Error("TLS handshake timed out")));
          s.once("error", done);
          s.once("secureConnect", () => {
            const got = hex(s.getPeerCertificate()?.fingerprint256);
            if (pin && got === pin) { s.setTimeout(0); return done(null, s); }
            s.destroy();
            done(new Error(pin ? `${url.host} presented certificate ${got}, not the pinned one` : `${url.host} is HTTPS with certificate ${got}; set PBX_TLS_PIN=${url.host}=${got} once it matches the PBX`));
          });
        },
      }, (res) => resolve(wrap(res)));
    }
    req.on("error", reject);
    req.end(body);
  });
}

function verify(ts, sig, raw) {
  const t = Number(ts);
  if (!Number.isFinite(t) || Math.abs(Date.now() - t) > 60_000) return false;
  const want = crypto.createHmac("sha256", SECRET).update(`${ts}.${raw}`).digest("hex");
  const a = Buffer.from(want), b = Buffer.from(String(sig || ""));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ── What the bridge has done, and how the PBX has answered ───────────────────
const stats = {
  requests: 0, fromCache: 0, joined: 0, badSignatures: 0,
  loginsReal: 0, loginsShared: 0, loginsHeld: 0, refusedReport: 0, refusedCredentials: 0, blocked: 0,
  sentToLogin: 0, droppedTokens: 0, retries: 0, timeouts: 0, unreachable: 0,
};
/** Every round trip to the PBX in the last 15 minutes. */
const recent = [];
function note(ms, outcome) {
  const at = Date.now();
  recent.push({ at, ms, outcome });
  while (recent.length && (recent.length > 20_000 || at - recent[0].at > 15 * 60_000)) recent.shift();
}
function summary(windowMs) {
  const now = Date.now();
  const w = recent.filter((x) => now - x.at < windowMs);
  const ms = w.filter((x) => x.outcome === "ok").map((x) => x.ms).sort((a, b) => a - b);
  const q = (p) => (ms.length ? ms[Math.min(ms.length - 1, Math.floor(p * ms.length))] : null);
  return {
    requests: w.length, p50: q(0.5), p95: q(0.95), max: ms.length ? ms[ms.length - 1] : null,
    over8s: ms.filter((x) => x > 8000).length, timeouts: w.filter((x) => x.outcome === "timeout").length, errors: w.filter((x) => x.outcome === "error").length,
  };
}

const json = (text) => { try { return JSON.parse(text); } catch { return null; } };
const failed = (status, errno, message) => { const j = { status: "Failed", errno, message }; return { kind: "reply", status, json: j, text: JSON.stringify(j) }; };
const succeeded = (j) => ({ kind: "reply", status: 200, json: j, text: JSON.stringify(j) });

/** One request to the PBX API. Never throws: a reply, "timeout" or "error". */
async function pbxCall(url, body, deadline, op) {
  const t0 = Date.now();
  const left = deadline - t0;
  if (left < 250) { stats.timeouts++; return { kind: "timeout", ms: 0 }; }
  const payload = JSON.stringify(body ?? {});
  try {
    const r = await pbxFetch(url, {
      method: "POST", headers: { "Content-Type": "application/json; charset=utf-8", "Content-Length": String(Buffer.byteLength(payload)) },
      body: payload, timeoutMs: left,
    });
    const text = await r.text();
    const ms = Date.now() - t0;
    note(ms, "ok");
    if (ms > 3000) log(`pbx ${op}: answered in ${ms} ms`);
    return { kind: "reply", status: r.status, text, json: json(text), ms };
  } catch (e) {
    const ms = Date.now() - t0;
    const timedOut = e?.name === "AbortError" || e?.name === "TimeoutError" || e?.code === "ABORT_ERR";
    note(ms, timedOut ? "timeout" : "error");
    if (timedOut) stats.timeouts++; else stats.unreachable++;
    log(`pbx ${op}: ${timedOut ? `no answer within ${ms} ms` : `unreachable (${e?.cause?.message ?? e?.message})`}`);
    return { kind: timedOut ? "timeout" : "error", ms };
  }
}

// ── The shared login ─────────────────────────────────────────────────────────
const DEAD = new Set(["20004", "20005", "20006"]); // no such token, token blank, token timed out
const AUTH = new Set(["20002", "20003", "30003"]); // API user locked, wrong user or password
const STALE_MS = 25 * 60_000; // the PBX erases a token after 30 minutes without use
const sessions = new Map(); // PBX host:port → the login every ConnectDesk server shares

function sessionOf(host) {
  let s = sessions.get(host);
  if (!s) sessions.set(host, (s = { host, loginUrl: "", creds: null, token: null, loginAt: 0, okAt: 0, logging: null, renewing: null, refused: null, issued: new Set() }));
  return s;
}
/**
 * Tokens this bridge has had from the PBX. Only a caller holding one of them
 * — which takes a login with the PBX's own credentials — is served with the
 * bridge's session. The bridge secret alone places no call and reads nothing.
 */
function issue(s, token) {
  s.issued.add(token);
  if (s.issued.size > 1000) s.issued.delete(s.issued.values().next().value);
}
const credsOf = (b) => JSON.stringify(["username", "password", "port", "version", "url", "urltag"].map((k) => String(b?.[k] ?? "")));
const live = (s) => !!s.token && Date.now() - s.okAt < STALE_MS;

/** A real login, one at a time per PBX: everyone who needs it waits on the same one. */
function realLogin(s, url, body, why, deadline) {
  if (s.logging) return s.logging;
  const key = credsOf(body);
  if (s.refused && s.refused.key === key && Date.now() < s.refused.until) { stats.loginsHeld++; return Promise.resolve(s.refused.r); }
  s.logging = (async () => {
    stats.loginsReal++;
    const r = await pbxCall(url, body, deadline, "login");
    if (r.kind === "reply" && r.json?.status === "Success" && r.json.token) {
      Object.assign(s, { loginUrl: url.href, creds: { ...body }, token: String(r.json.token), loginAt: Date.now(), okAt: Date.now(), refused: null });
      issue(s, s.token);
      log(`login (${why}): ok in ${r.ms} ms`);
    } else if (r.kind === "reply") {
      const errno = String(r.json?.errno ?? `HTTP ${r.status}`);
      // Not again with the same credentials for a while: five failed logins in
      // a row lock the API user for ten minutes, and other systems use it too.
      s.refused = { key, until: Date.now() + (AUTH.has(errno) ? 180_000 : 15_000), r };
      if (s.creds && credsOf(s.creds) === key) s.token = null;
      log(`login (${why}): refused, errno ${errno}`);
    }
    return r;
  })().finally(() => { s.logging = null; });
  return s.logging;
}

/**
 * The PBX dropped the bridge's token: another login from this address (CallBox
 * logs in before every click), a restart, or 30 idle minutes. One new login for
 * everyone waiting, after a pause that lets the login which replaced ours be
 * used first.
 */
function renew(s, why, deadline) {
  if (!s.renewing) {
    s.token = null;
    s.renewing = (async () => { await sleep(SETTLE_MS); return realLogin(s, new URL(s.loginUrl), s.creds, why, deadline); })()
      .finally(() => { s.renewing = null; });
  }
  return s.renewing;
}

async function onLogin(s, url, body, deadline) {
  const off = GUARDED.filter((k) => String(body?.[k] ?? "").trim() !== REPORT[k]);
  if (off.length) {
    stats.refusedReport++;
    log(`login refused here: its report ${off.join(", ")} differ from PBX_REPORT_* (it would move the PBX's event feed)`);
    return failed(403, "BRIDGE_REPORT_MISMATCH", `This login's event-report ${off.join(", ")} differ from the target the PBX already reports to: it would move that call feed.`);
  }
  if (LOGIN_SHA && crypto.createHash("sha256").update(`${body?.username ?? ""}:${body?.password ?? ""}`).digest("hex") !== LOGIN_SHA) {
    stats.refusedCredentials++;
    log("login refused here: not the API user and password in PBX_LOGIN_SHA256");
    return failed(403, "BRIDGE_CREDENTIALS_MISMATCH", "This API user or password is not the PBX's own; refused before the PBX could count a failed login.");
  }
  if (MODE === "passthrough") return pbxCall(url, body, deadline, "login");
  const same = !!s.creds && credsOf(s.creds) === credsOf(body);
  if (same && (s.renewing || s.logging)) await (s.renewing || s.logging);
  if (same && live(s)) { stats.loginsShared++; return succeeded({ status: "Success", token: s.token }); }
  return realLogin(s, url, body, !s.creds ? "first" : same ? (s.token ? "idle" : "dropped") : "new credentials", deadline);
}

/** An API call with the bridge's token; a dropped token is replaced and the call retried. */
async function withToken(s, url, op, body, deadline, gone) {
  if (!live(s)) {
    const r = await (s.renewing || s.logging || realLogin(s, new URL(s.loginUrl), s.creds, s.token ? "idle" : "dropped", deadline));
    // No session: the login's own refusal or silence, which ConnectDesk reports as it is.
    if (!s.token) return r && !(r.kind === "reply" && r.json?.status === "Success") ? r : failed(200, "20004", "The bridge has no PBX session.");
  }
  for (let attempt = 0; ; attempt++) {
    const used = s.token;
    url.searchParams.set("token", used);
    const r = await pbxCall(url, body, deadline, op);
    if (r.kind !== "reply") return r; // no answer: never repeated, the PBX may have acted on it
    const errno = String(r.json?.errno ?? "");
    if (!DEAD.has(errno)) {
      if (r.json?.status === "Success") s.okAt = Date.now();
      return r;
    }
    stats.droppedTokens++;
    log(`pbx ${op}: token dropped (${errno})`);
    if (attempt >= 2 || gone() || deadline - Date.now() < 1500) return r;
    if (s.token === used) await renew(s, `token dropped (${errno})`, deadline);
    else if (s.renewing || s.logging) await (s.renewing || s.logging);
    if (!s.token || gone()) return r;
    stats.retries++;
  }
}

const READS = { "extensionlist/query": 2000, "outbound/query": 1500 };
const cache = new Map();
const joining = new Map();

async function onApi(s, url, op, body, deadline, gone) {
  if (MODE === "passthrough") return pbxCall(url, body, deadline, op);
  if (!s.creds || !s.issued.has(url.searchParams.get("token") ?? "")) {
    // Not a token this bridge handed out: one from a ConnectDesk server's own
    // session from before the bridge (which must not be kept alive from here),
    // one from before this bridge restarted, or none. Told it is gone, the
    // ConnectDesk server logs in through the bridge and gets the shared one.
    stats.sentToLogin++;
    return failed(200, "20004", "Not a token from this bridge: log in through it.");
  }
  const ttl = READ_CACHE ? READS[op] ?? 0 : 0;
  if (!ttl) {
    const r = await withToken(s, url, op, body, deadline, gone);
    // A call placed, ended or held: the next poll asks the PBX again.
    if (r.kind === "reply" && r.json?.status === "Success" && !op.startsWith("recording/")) {
      for (const k of cache.keys()) if (k.startsWith(`${s.host}|`)) cache.delete(k);
    }
    return r;
  }
  const key = `${s.host}|${op}|${JSON.stringify(body ?? {})}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttl) { stats.fromCache++; return hit.r; }
  const pending = joining.get(key);
  if (pending) { stats.joined++; return pending; }
  const p = withToken(s, url, op, body, deadline, gone)
    .then((r) => { if (r.kind === "reply" && r.json?.status === "Success") cache.set(key, { at: Date.now(), r }); return r; })
    .finally(() => joining.delete(key));
  joining.set(key, p);
  return p;
}

// ── HTTP ─────────────────────────────────────────────────────────────────────
const API = /^\/+api\/v[0-9.]+\/(.+?)\/*$/i;
const NEVER = new Set(["logout", "heartbeat"]);

const sendJson = (res, code, body) => { if (res.headersSent) return; res.writeHead(code, { "Content-Type": "application/json" }); res.end(typeof body === "string" ? body : JSON.stringify(body)); };
function answer(res, r) {
  if (r.kind === "reply") return sendJson(res, r.status || 200, r.text ?? JSON.stringify(r.json));
  const f = r.kind === "timeout"
    ? failed(504, "BRIDGE_TIMEOUT", `The PBX did not answer within ${Math.round(BUDGET_MS / 1000)} seconds.`)
    : failed(502, "BRIDGE_UNREACHABLE", "The PBX could not be reached from the bridge.");
  sendJson(res, f.status, f.text);
}
// Funnel makes this address public, so a bad signature is logged once a minute at most.
let badSigLogged = 0;
function badSignature(res) {
  stats.badSignatures++;
  if (Date.now() - badSigLogged > 60_000) {
    badSigLogged = Date.now();
    log("refused a request with a bad or stale signature: the secret in ConnectDesk differs from BRIDGE_SECRET, or a clock is more than 60 s off");
  }
  sendJson(res, 401, { ok: false, status: "Failed", errno: "BRIDGE_BAD_SIGNATURE", message: "bad signature" });
}
function readBody(req, max) {
  return new Promise((resolve) => {
    let raw = "";
    req.setEncoding("utf8");
    req.on("data", (c) => { raw += c; if (raw.length > max) { resolve(null); req.destroy(); } });
    req.on("end", () => resolve(raw));
    req.on("error", () => resolve(null));
  });
}
function target(raw, res) {
  let url;
  try { url = new URL(JSON.parse(raw).url); } catch { sendJson(res, 400, { ok: false, message: "bad url" }); return null; }
  if (url.protocol !== "http:" && url.protocol !== "https:") { sendJson(res, 400, { ok: false }); return null; }
  if (!ALLOW.has(url.host.toLowerCase())) { sendJson(res, 403, { ok: false, message: `${url.host} is not on PBX_ALLOW` }); return null; }
  const m = API.exec(url.pathname);
  if (!m) { sendJson(res, 400, { ok: false, message: "not a PBX API path" }); return null; }
  return { url, op: m[1].toLowerCase() };
}

async function onPbx(req, res) {
  const raw = await readBody(req, 64_000);
  if (raw === null) return;
  if (!verify(req.headers["x-bridge-ts"], req.headers["x-bridge-sig"], raw)) return badSignature(res);
  stats.requests++;
  const t = target(raw, res);
  if (!t) return;
  if (NEVER.has(t.op)) {
    stats.blocked++;
    log(`refused ${t.op}: never forwarded`);
    return answer(res, failed(403, "BRIDGE_BLOCKED", `${t.op} is never forwarded: it could drop or re-point the PBX's event reports for this address.`));
  }
  const body = JSON.parse(raw).body ?? {};
  const deadline = Date.now() + BUDGET_MS;
  let clientGone = false;
  res.on("close", () => { if (!res.writableFinished) clientGone = true; });
  const s = sessionOf(t.url.host.toLowerCase());
  answer(res, t.op === "login" ? await onLogin(s, t.url, body, deadline) : await onApi(s, t.url, t.op, body, deadline, () => clientGone));
}

// POST /pbx-file {url} — a call recording, streamed back as the PBX sent it.
async function onPbxFile(req, res) {
  const raw = await readBody(req, 8_000);
  if (raw === null) return;
  if (!verify(req.headers["x-bridge-ts"], req.headers["x-bridge-sig"], raw)) return badSignature(res);
  const t = target(raw, res);
  if (!t) return;
  if (t.op !== "recording/download") return sendJson(res, 400, { ok: false, message: "only call recordings are fetched here" });
  const s = sessions.get(t.url.host.toLowerCase());
  // The download is checked against the token that asked for it (recording/get_random): the bridge's.
  if (MODE === "shared" && s?.token && s.issued.has(t.url.searchParams.get("token") ?? "")) t.url.searchParams.set("token", s.token);
  try {
    const r = await pbxFetch(t.url, { timeoutMs: 30_000 });
    const headers = { "Content-Type": r.headers.get("content-type") || "application/octet-stream" };
    const len = r.headers.get("content-length");
    if (len) headers["Content-Length"] = len;
    res.writeHead(r.status, headers);
    let sent = 0;
    for await (const chunk of r.body) {
      sent += chunk.length;
      if (sent > 128 * 1024 * 1024) { res.destroy(); return; }
      res.write(chunk);
    }
    res.end();
    log("pbx-file", t.url.pathname, r.status, sent);
  } catch (e) {
    log("pbx-file error", t.url.pathname, e?.message);
    if (!res.headersSent) sendJson(res, 502, { ok: false, message: "PBX unreachable from the bridge" });
    else res.destroy();
  }
}

const started = Date.now();
const iso = (t) => (t ? new Date(t).toISOString() : null);
function health() {
  return {
    ok: true, service: "pbx-bridge", version: VERSION, mode: MODE,
    reportTarget: GUARDED.length ? "pinned" : "any", apiUser: LOGIN_SHA ? "pinned" : "any", sourceIp: SOURCE_IP || null,
    allow: [...ALLOW], pinned: [...PINS.keys()], scheduler: !!(CONNECTDESK && CRON_SECRET), upSec: Math.round((Date.now() - started) / 1000),
    sessions: [...sessions.values()].map((s) => ({ pbx: s.host, live: live(s), loggedInAt: iso(s.loginAt), lastOkAt: iso(s.okAt) })),
    counts: { ...stats },
    pbxLast15Min: summary(15 * 60_000),
  };
}

const server = http.createServer((req, res) => {
  const fail = (e) => { log("bridge error", e?.message); sendJson(res, 500, { ok: false }); };
  if (req.method === "GET" && req.url === "/health") return sendJson(res, 200, health());
  if (req.method === "POST" && req.url === "/pbx") return void onPbx(req, res).catch(fail);
  if (req.method === "POST" && req.url === "/pbx-file") return void onPbxFile(req, res).catch(fail);
  sendJson(res, 404, { ok: false });
});
// Loopback by default: Tailscale Funnel connects to it locally, and nothing on
// the LAN or the tailnet has any business reaching it directly.
server.listen(PORT, HOST, () => log(
  `telephony bridge ${VERSION} on ${HOST}:${PORT}: ${MODE} session; allow ${[...ALLOW].join(", ")}` +
  `${GUARDED.length ? `; report target pinned (${GUARDED.join(", ")})` : ""}${LOGIN_SHA ? "; API user pinned" : ""}` +
  `${SOURCE_IP ? `; calls the PBX from ${SOURCE_IP}` : ""}${PINS.size ? `; TLS pinned ${[...PINS.keys()].join(", ")}` : ""}`,
));

// One line a minute while there is traffic: the PBX's latency and the logins it cost.
let before = { ...stats };
setInterval(() => {
  const d = Object.fromEntries(Object.keys(stats).map((k) => [k, stats[k] - before[k]]));
  before = { ...stats };
  const m = summary(60_000);
  if (!d.requests && !m.requests) return;
  log(`minute: ${d.requests} requests, ${d.fromCache + d.joined} shared; PBX ${m.requests} calls, p50 ${m.p50 ?? "-"} ms, p95 ${m.p95 ?? "-"} ms, max ${m.max ?? "-"} ms, ` +
    `${m.timeouts} without answer, ${m.errors} unreachable; logins ${d.loginsReal} real, ${d.loginsShared} shared; ${d.droppedTokens} tokens dropped, ${d.retries} retried`);
}, 60_000).unref();

// ── The floor's scheduler ────────────────────────────────────────────────────
if (CONNECTDESK && CRON_SECRET) {
  const tick = async () => {
    try {
      const r = await fetch(`${CONNECTDESK}/api/cron/desk-floor`, { headers: { authorization: `Bearer ${CRON_SECRET}` }, signal: AbortSignal.timeout(55_000) });
      if (!r.ok) log("floor tick", r.status);
    } catch (e) { log("floor tick failed", e?.message); }
  };
  setInterval(tick, 60_000);
  void tick();
  log("floor scheduler: every 60 s →", CONNECTDESK);
}
