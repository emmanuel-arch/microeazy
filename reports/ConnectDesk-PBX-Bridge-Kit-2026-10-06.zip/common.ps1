# -----------------------------------------------------------------------------
# Shared by check.ps1 and install.ps1 (dot-sourced). Keep this file ASCII:
# Windows PowerShell 5.1 reads a .ps1 without a BOM in the ANSI code page.
# -----------------------------------------------------------------------------

function Ok($s)   { Write-Host "  [ OK ] $s" -ForegroundColor Green }
function No($s)   { Write-Host "  [FAIL] $s" -ForegroundColor Red }
function Warn($s) { Write-Host "  [WARN] $s" -ForegroundColor Yellow }
function Note($s) { Write-Host "         $s" -ForegroundColor DarkGray }
function Head($s) { Write-Host ""; Write-Host $s -ForegroundColor White }

function Test-Admin {
  return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-TailscaleExe {
  $cmd = Get-Command tailscale -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  if (Test-Path "C:\Program Files\Tailscale\tailscale.exe") { return "C:\Program Files\Tailscale\tailscale.exe" }
  return $null
}

function Get-TailnetSelf($ts) {
  try { return ((& $ts status --json 2>$null | Out-String) | ConvertFrom-Json).Self } catch { return $null }
}

# nssm.exe: the path given, then PATH, then this folder, then the nssm.exe an
# existing NSSM service runs (the SQL relay on servicesuite-in is one).
function Get-NssmExe([string]$root, [string]$given) {
  if ($given) { if (Test-Path $given) { return $given } else { return $null } }
  $cmd = Get-Command nssm -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  if (Test-Path (Join-Path $root "nssm.exe")) { return (Join-Path $root "nssm.exe") }
  foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
    if ("$($s.PathName)" -match '^\s*"?([^"]*\\nssm\.exe)"?') { if (Test-Path $Matches[1]) { return $Matches[1] } }
  }
  return $null
}

# What Tailscale serves on each port, from `tailscale serve status`:
#   "443" -> "http://127.0.0.1:10001", "8443" -> "http://127.0.0.1:8787", ...
# A port that is served some other way maps to "". https://host with no port is 443.
function Get-ServeMap($ts) {
  $map = @{}
  $port = $null
  foreach ($l in @(& $ts serve status 2>&1 | ForEach-Object { "$_" })) {
    if ($l -match '^(https|http|tcp)://[^\s/:]+(?::(\d+))?') {
      if ($Matches[2]) { $port = $Matches[2] } elseif ($Matches[1] -eq "https") { $port = "443" } else { $port = "80" }
      $map[$port] = ""
    } elseif ($port -and $l -match '\|--\s+/\s+proxy\s+(\S+)') {
      $map[$port] = $Matches[1]
    }
  }
  return $map
}

function Get-PublicIp {
  try { return ("" + (Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 10)).Trim() } catch { return $null }
}

function Get-Listener([int]$port) {
  $l = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $l) { return $null }
  $p = Get-Process -Id $l.OwningProcess -ErrorAction SilentlyContinue
  return "$($p.ProcessName) (pid $($l.OwningProcess))"
}

# Folders that may hold a CallBox: every IIS site and application, then the usual places.
function Get-SiteFolders {
  $dirs = New-Object System.Collections.Generic.List[string]
  try {
    Import-Module WebAdministration -ErrorAction Stop
    foreach ($s in Get-Website) { $dirs.Add([Environment]::ExpandEnvironmentVariables("$($s.physicalPath)")) }
    foreach ($a in Get-WebApplication) { $dirs.Add([Environment]::ExpandEnvironmentVariables("$($a.PhysicalPath)")) }
  } catch { }
  foreach ($d in @("C:\inetpub\wwwroot", "C:\inetpub", "C:\Sites", "D:\Sites", "C:\CallBox", "D:\CallBox", "C:\Publish", "D:\Publish")) {
    if (Test-Path $d) {
      $dirs.Add($d)
      Get-ChildItem $d -Directory -ErrorAction SilentlyContinue | ForEach-Object { $dirs.Add($_.FullName) }
    }
  }
  return @($dirs | Select-Object -Unique)
}

# One CallBox: its settings file, its HostSettings, the PBX (host:port) they drive,
# and whether it logs in at all (isPbxConfigured=1).
function New-CallBoxCopy([string]$file, $hs) {
  $t = Get-PbxTarget $hs
  $hp = ""
  if ($t) { $hp = $t.HostPort }
  return New-Object PSObject -Property @{ File = (Resolve-Path $file).Path; Hs = $hs; Pbx = $hp; LogsIn = ("$($hs['isPbxConfigured'])" -eq "1") }
}

# Every CallBox on this server: an appsettings.json with an active HostSettings
# block. servicesuite-in holds several, one per client, each with its own PBX.
function Get-CallBoxCopies([string[]]$folders) {
  if (-not $folders) { $folders = Get-SiteFolders }
  $out = @()
  foreach ($d in $folders) {
    $f = Join-Path $d "appsettings.json"
    if (-not (Test-Path $f)) { continue }
    $hs = Read-HostSettings $f
    if ($hs) { $out += New-CallBoxCopy $f $hs }
  }
  return $out
}

function Get-LoginKey($hs) {
  return ((@("username", "password", "port", "version", "url", "urltag") | ForEach-Object { "$($hs[$_])" }) -join "|")
}

# The CallBox that logs in to the PBX at $pbxHost (host:port). -CallBoxSettings
# names it outright; otherwise it is the copy whose HostSettings point there with
# isPbxConfigured=1. Copies that log in with the same user, password and report
# target are one CallBox; copies that disagree stop the scripts.
# Returns @{ Copy; Same } or @{ Error; Conflict }.
function Select-CallBox($copies, [string]$hint, [string]$pbxHost) {
  if ($hint) {
    if (-not (Test-Path $hint)) { return @{ Error = "$hint does not exist" } }
    $hs = Read-HostSettings $hint
    if (-not $hs) { return @{ Error = "no active HostSettings in $hint" } }
    $c = New-CallBoxCopy $hint $hs
    if ($c.Pbx -ne $pbxHost) { return @{ Error = "$hint drives the PBX at '$($c.Pbx)', not $pbxHost" } }
    return @{ Copy = $c; Same = @() }
  }
  $hits = @($copies | Where-Object { $_.Pbx -eq $pbxHost -and $_.LogsIn })
  if ($hits.Count -eq 0) {
    if (@($copies | Where-Object { $_.Pbx -eq $pbxHost }).Count) { return @{ Error = "the CallBox copies pointing at $pbxHost have isPbxConfigured=0, so none logs in: pass -CallBoxSettings for the live one" } }
    return @{ Error = "no CallBox on this server logs in to ${pbxHost}: pass -CallBoxSettings <its appsettings.json>" }
  }
  $keys = @($hits | ForEach-Object { Get-LoginKey $_.Hs } | Select-Object -Unique)
  if ($keys.Count -gt 1) { return @{ Error = "$($hits.Count) CallBox copies log in to $pbxHost with different settings: pass -CallBoxSettings for the live one"; Conflict = $hits } }
  return @{ Copy = $hits[0]; Same = @($hits | Select-Object -Skip 1) }
}

# One line per copy that disagrees: what differs, never the password itself.
function Show-Conflict($conflict) {
  $pw = @($conflict | ForEach-Object { "$($_.Hs['password'])" } | Select-Object -Unique)
  foreach ($c in $conflict) {
    Note ("{0}: user {1}, report {2} {3} tag {4} v{5}, password #{6}" -f $c.File, $c.Hs["username"], $c.Hs["port"], $c.Hs["url"], $c.Hs["urltag"], $c.Hs["version"], ([array]::IndexOf($pw, "$($c.Hs['password'])") + 1))
  }
}

# The active "HostSettings" block of one settings file (commented-out blocks are
# skipped: CallBox's file keeps several). $null when there is none.
function Read-HostSettingsFile([string]$file) {
  $live = @(Get-Content $file -ErrorAction SilentlyContinue | Where-Object { $_ -notmatch '^\s*//' }) -join "`n"
  if ($live -notmatch '"HostSettings"\s*:\s*\{([^}]*)\}') { return $null }
  $h = @{}
  foreach ($m in [regex]::Matches($Matches[1], '"([A-Za-z]+)"\s*:\s*(?:"([^"]*)"|([^,\s}]+))')) {
    if ($m.Groups[2].Success) { $h[$m.Groups[1].Value] = $m.Groups[2].Value } else { $h[$m.Groups[1].Value] = $m.Groups[3].Value }
  }
  return $h
}

# appsettings.json, then appsettings.Production.json over it, as ASP.NET Core reads them.
function Read-HostSettings([string]$file) {
  $h = Read-HostSettingsFile $file
  $prod = Join-Path (Split-Path $file) "appsettings.Production.json"
  if (Test-Path $prod) {
    $p = Read-HostSettingsFile $prod
    if ($p) { if (-not $h) { $h = @{} }; foreach ($k in $p.Keys) { $h[$k] = $p[$k] } }
  }
  return $h
}

function Get-Sha256Hex([string]$s) {
  $b = [Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($s))
  return (($b | ForEach-Object { $_.ToString("x2") }) -join "")
}

function Read-DotEnv([string]$file) {
  $cfg = @{}
  if (-not (Test-Path $file)) { return $cfg }
  foreach ($line in Get-Content $file) {
    if ($line -match '^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$') {
      $v = $Matches[2]
      if ($v.Length -ge 2 -and (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'")))) { $v = $v.Substring(1, $v.Length - 2) }
      $cfg[$Matches[1]] = $v
    }
  }
  return $cfg
}

# One POST to the PBX API. Returns the parsed answer, or $null with no answer.
function Invoke-PbxPost([string]$url, $obj, [int]$timeoutSec = 20) {
  $json = $obj | ConvertTo-Json -Compress
  try { return Invoke-RestMethod -Method Post -Uri $url -Body $json -ContentType "application/json" -TimeoutSec $timeoutSec } catch { return $null }
}

# The PBX's API base (".../api/v1.1.0") and host:port, from CallBox's BaseUrl or ApiUrl.
function Get-PbxTarget($hs) {
  $src = $hs["BaseUrl"]
  if (-not $src) { $src = $hs["ApiUrl"] }
  if (-not $src) { return $null }
  try { $u = [Uri]$src } catch { return $null }
  return @{ HostPort = $u.Authority; ApiBase = "$($u.Scheme)://$($u.Authority)/api/v1.1.0" }
}
