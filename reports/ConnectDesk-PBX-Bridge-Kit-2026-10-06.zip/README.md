# ConnectDesk PBX bridge on servicesuite-in

**What it fixes.** Fastdial's agents see *"not connected · The PBX did not answer within 9 seconds."* ConnectDesk
called Fastdial's Yeastar S50 straight from Vercel, whose servers keep changing their internet address, and each
new address became one more API session on the PBX. The PBX sends every call event once per session, so CallBox's
receiver was getting each one 10 to 38 times. As the copies grew, the PBX's API slowed to 2–20 seconds, and its
call engine restarted (08:12, 08:21 and 08:31 on 6 Oct, which is the "every 10 minutes" the supervisors see).

**What this does.** It runs one small service on servicesuite-in (213.148.17.228), the machine and address CallBox
already calls the PBX from. All of ConnectDesk's PBX traffic goes through it, with **one** login shared by every
ConnectDesk server. To the PBX, ConnectDesk and CallBox become one application server, so every event goes out once.

**What it never does to CallBox.** It logs in only with CallBox's exact API user and event-report target, so
CallBox's call feed never moves. It never logs out and never sends a heartbeat. It never retries a login the PBX
refused, so the API user is never locked. CallBox, IIS (which keeps 443) and the SQL relay (Funnel 8443) are not
stopped, restarted or reconfigured. The bridge is published on Funnel **10000**.

---

## 0. Before you start

- RDP to **servicesuite-in** as an administrator. Run everything below in **an elevated PowerShell** (Run as administrator).
- Node 20 or later: v24 is already on this box for the Interchange engine.
- **NSSM**: the scripts use the `nssm.exe` the SQL relay's service already runs. Only if `check.ps1` finds none, put
  `win64\nssm.exe` from https://nssm.cc/download in the kit folder.
- **Which CallBox.** This server holds several CallBoxes, one per client (CallBoxMaster, FastDial, FastDialCallCenter,
  NewPremiumEdge, Ozol, Esken), each with its own PBX. Fastdial's live one is **`C:\inetpub\wwwroot\FastDial`**,
  and both scripts are told so with `-CallBoxSettings`. They refuse a CallBox whose PBX is not Fastdial's
  (197.248.179.183:8088).

## 1. Copy the kit

Unzip `ConnectDesk-PBX-Bridge-Kit-<date>.zip` to `C:\ConnectDesk\pbx-bridge` (not Downloads or Desktop:
`install.ps1` locks the folder down).

## 2. Check

```powershell
cd C:\ConnectDesk\pbx-bridge
powershell -ExecutionPolicy Bypass -File check.ps1 -SessionTest -CallBoxSettings "C:\inetpub\wwwroot\FastDial\appsettings.json"
```

Every line must be `[ OK ]` or `[WARN]`. It confirms:

- this is servicesuite-in, and it reaches the internet from 213.148.17.228;
- Funnel 10000 is free for the bridge (8443, the SQL relay, is listed and left alone; 443 stays IIS's);
- port 10001 is free;
- the PBX API answers;
- every CallBox on the server with the PBX it drives, and the PBX settings of Fastdial's (the password is never shown).

`-SessionTest` logs in to the PBX twice, exactly as CallBox does before every click, and answers one question:
**does a second login from this address cancel the first token?** Send the developer the answer (`INDEPENDENT` or
`ONE TOKEN PER ADDRESS`). Either way the bridge works. It only changes how often the bridge has to log in again.

## 3. Install

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1 -Install -Publish -CallBoxSettings "C:\inetpub\wwwroot\FastDial\appsettings.json"
```

It:

- writes `.env` from CallBox's own settings and generates the secret;
- locks the folder to Administrators, SYSTEM and LocalService;
- installs and starts the service **ConnectDeskPbxBridge** (auto start, restarts 5 s after any exit);
- waits for it to answer;
- publishes it with Tailscale Funnel on 10000, then checks that every other Funnel port is exactly as it was.

It ends by printing **the URL and the secret** for ConnectDesk.

## 4. Prove it from outside

On a phone **on mobile data with Tailscale off** (that is how Vercel reaches it), open
`https://servicesuite-in.tail10c441.ts.net:10000/health`. It should show `{"ok":true,"service":"pbx-bridge","mode":"shared",…}`.

## 5. Point ConnectDesk at it

Signed in to **Fastdial's** ConnectDesk as an administrator, go to Settings → Connections & seats → Phone system →
**Telephony bridge — when the PBX only accepts a fixed IP**:

| Field | Value |
|---|---|
| Bridge URL | `https://servicesuite-in.tail10c441.ts.net:10000` (what install.ps1 printed) |
| Secret | the secret install.ps1 printed (also in `.env`) |

**Save**, then **Test**. Expect: *"Logged in. N extensions, M registered right now."* Place one call from the
handset. Then do the same for **Mular Credit**, whose desk uses the same PBX.

The switch is immediate: ConnectDesk reads this setting on every request.

## 6. What you should see

- `/health` → `counts.loginsReal` stays small and `loginsShared` climbs: the bridge answers ConnectDesk's logins
  itself.
- `logs\ConnectDeskPbxBridge.log` → one line a minute with the PBX's response times (p50, p95, max) and any
  request it did not answer.
- Within about 40 minutes, the old Vercel sessions expire on the PBX and every call event reaches CallBox once
  instead of 20 times. The developer watches this from CallBox's records.

## 7. Rollback

- **ConnectDesk:** clear the Bridge URL and Save, for each organisation. ConnectDesk calls the PBX directly again,
  as before.
- **This server:** `powershell -ExecutionPolicy Bypass -File install.ps1 -Remove`. It removes the service and
  its Funnel port (10000) only.

## 8. When something is wrong

| Symptom | Meaning |
|---|---|
| Test: *"The PBX refused extensionlist/query (BRIDGE_REPORT_MISMATCH)"* or *"…event-report target…"* | ConnectDesk's report target differs from CallBox's: copy port `8260`, url, urltag `1`, version `1.0.2` exactly from CallBox's HostSettings |
| Test: *"…API user or password is not the PBX's own"* (BRIDGE_CREDENTIALS_MISMATCH) | ConnectDesk's API password differs from CallBox's: paste CallBox's MD5 as it is |
| Test: *"…bridge secret saved here is not the bridge's…"* (BRIDGE_BAD_SIGNATURE); the log says *"refused a request with a bad or stale signature"* | The secret differs between `.env` and ConnectDesk, or this server's clock is off by more than a minute |
| `/health` from mobile data times out | Funnel 10000 is not on, or Tailscale stopped (unattended mode off, key expired): `tailscale serve status` |
| `/health` → 502 with an empty body | Funnel is up but the service is not: `Get-Service ConnectDeskPbxBridge`, then `logs\` |
| Agents: *"The PBX did not answer within 8 seconds."* | The PBX itself is slow; the log's minute lines show how slow. Not the bridge |
| CallBox users report clicks that fail | Tell the developer the session-test answer. With one token per address, a second public IP for the bridge (`BRIDGE_SOURCE_IP`) separates it from CallBox |

## 9. Updating

Copy the new `pbx-bridge.mjs` over the old one, then `Restart-Service ConnectDeskPbxBridge`. `.env` and the
service stay. `VERSION` says which build this is.
