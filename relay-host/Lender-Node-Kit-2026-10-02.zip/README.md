# Lender node: Micromart (`lms`)

Two small services on Micromart's own server, so Micromart's systems stop depending on anyone else's machine:

| Service | Listens on | Published as (Tailscale Funnel) | Used by |
|---|---|---|---|
| `LenderNodeSqlRelay` (`sql-relay.cjs`) | 127.0.0.1:8787 | `https://lms.tail10c441.ts.net:8443` | every Micromart screen in all six systems: reads and writes to `Serviceconnect` and `CollectBox` |
| `LenderNodePbxBridge` (`pbx-bridge.mjs`) | 127.0.0.1:10001 | `https://lms.tail10c441.ts.net:10000` | ConnectDesk's phone: Call in the handset, hang up, hold, listen, recordings |

**Why `lms`.** It is a VM inside the `services` box, Micromart's SQL Server, so a relay here adds no new point of
failure: if this box is down, the database is down with it. SQL travels over the LAN instead of across the tailnet.
The shared relay on servicesuite-in stays behind it as the fallback for reads.

**What stays where.** Vercel holds two secrets and no passwords. The SQL password and the PBX's API password never
leave Micromart. This server holds only Micromart's connection strings (`install.ps1` refuses any other lender's)
and its own relay secret, never the shared one.

---

## 0. Before you start

- RDP to `lms` as an administrator. Everything below runs in **an elevated PowerShell** (Run as administrator).
- **Node 24 LTS (x64 MSI)** from nodejs.org. Open a new PowerShell after installing it.
- **NSSM 2.24** from https://nssm.cc/download: put `win64\nssm.exe` in the kit folder.
- From servicesuite-in's relay `.env`: the lines `SERVICESUITE_CONN_MICROMART` and `MICROMART_FINTECH`.
- From CollectBox's `appsettings.json` (`HostSettings`): the PBX API user, its password (already MD5) and the event
  report values.
- Access to the Vercel project and to the Tailscale admin console.

## 1. Copy the kit

Unzip `Lender-Node-Kit-<date>.zip` to `C:\LenderNode` on `lms`. Keep the files together: both services read
`C:\LenderNode\.env`.

## 2. Pre-flight

```powershell
cd C:\LenderNode
powershell -ExecutionPolicy Bypass -File check-node.ps1
```

Read-only. Fix every `[FAIL]` before going on. The VERDICT at the end tells you:

- which address reaches the SQL Server (`192.168.0.234,4230` over the LAN is the best; `100.72.35.56,4230` over
  Tailscale works too),
- which address reaches the PBX API, and, for HTTPS, the certificate fingerprint to pin,
- the address the PBX will see, for its API allowed-IP list.

If it says there is no road to the PBX, install the SQL relay only (`-Sql`) and keep calls on the current bridge.

## 3. `.env`

```powershell
copy .env.example .env
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"   # relay secret
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"   # bridge secret
notepad .env
```

Fill it in from the comments and the VERDICT. Keep the two new secrets somewhere safe: each goes in exactly one
other place (Vercel for the relay's, ConnectDesk for the bridge's).

The write posture **must match the shared relay**, which is armed (`writes: true`, one allowed procedure, on
2 Oct 2026). Micromart's writes go to this relay first and are never retried on another one, so a read-only `lms`
would refuse every outcome an agent saves.

## 4. Install

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1 -Sql -Pbx -Publish
```

It checks `.env`, closes the folder to everyone but Administrators, SYSTEM and LocalService, installs both
services (auto start, restart 5 s after any exit), waits for both `/health` answers, turns on Tailscale's
unattended mode and publishes both ports. It ends with `tailscale funnel status`: **8443 and 10000 must both be
listed**. Leave 443 alone; something else on this server answers there.

Logs: `C:\LenderNode\logs\`. The relay's log shows `writes: ARMED` and `Micromart Africa pool open (… ms)`.

## 5. Uptime settings

1. Tailscale admin console → Machines → `lms` → **Disable key expiry**. Otherwise the node drops off the internet
   when its key expires (the pre-flight shows the date).
2. Confirm unattended mode is on (the pre-flight says so). Without it, signing out of RDP takes both URLs down.
3. Windows Update: set active hours to cover the working day, so patch reboots happen at night. Both services and
   Tailscale come back on their own.

## 6. Prove it survives a restart

Reboot `lms` when it is safe for whatever else runs on it (or restart both services). Then, on a phone using
**mobile data with Tailscale off**, which is how Vercel sees it, open:

- `https://lms.tail10c441.ts.net:8443/health` → `{"ok":true,"service":"sql-relay",…,"writes":true,"allowedProcs":1}`
- `https://lms.tail10c441.ts.net:10000/health` → `{"ok":true,"allow":[…],…}`

From a tailnet PC the same names resolve over Tailscale instead, which proves the services but not Funnel.

## 7. Point the cloud at it

1. On the workstation, prove the signed path before Vercel uses it:

   ```powershell
   cd C:\GIT\MICRO_EAZY\connected-suite
   $env:SERVICESUITE_RELAY_URL_MICROMART = "https://lms.tail10c441.ts.net:8443"
   $env:SERVICESUITE_RELAY_SECRET_MICROMART = "<the relay secret>"
   npm run relay:verify
   ```

   Every road answers, and the read says `answered by https://lms.tail10c441.ts.net:8443`.
2. Vercel → the project → Settings → Environment Variables (Production):
   - `SERVICESUITE_RELAY_URL_MICROMART` = `https://lms.tail10c441.ts.net:8443`
   - `SERVICESUITE_RELAY_SECRET_MICROMART` = the relay secret
   - leave `SERVICESUITE_RELAY_URL` / `SERVICESUITE_RELAY_SECRET` as they are: they serve every other lender, and
     Micromart falls back to them for reads.
3. Deploy (push the commit that adds `relayKey`, or Redeploy). Env changes only reach new deployments.
4. Open any Micromart screen. `lms`'s `/health` `served` count climbs; servicesuite-in's stops climbing for Micromart.

## 8. ConnectDesk's phone system

Signed in to Micromart's ConnectDesk as an administrator: Settings → Connections & seats → **Phone system**:

| Field | Value |
|---|---|
| Driver | Yeastar S-Series |
| Answer the agent's own leg automatically | Yes |
| API address | what the VERDICT printed, e.g. `https://192.168.1.150:8088/api/v1.1.0` or `http://197.248.211.105:8088/api/v1.1.0` |
| API user | `api` (CollectBox `HostSettings.username`) |
| API password | CollectBox's `HostSettings.password` as it is: the field takes an MD5 directly |
| Event report target | `8260` · `192.168.1.100:8260/Pbx/application/service/Report` · `1` · `1.0.2`, exactly CollectBox's |
| Telephony bridge | `https://lms.tail10c441.ts.net:10000` and the bridge secret |

Save, then **Test**. It logs in to the PBX through `lms` and counts extensions. A login carrying any other report
target would move CollectBox's call feed, which is why those four values are copied, never typed fresh.

## 9. Every agent can call

1. Settings → Connections & seats → **Seats on this floor**: in the panel on the right, tick Micromart's agents
   (their CollectBox extension shows beside each name) and press **Bring … onto the floor**. Extensions come from
   CollectBox's `PBXExtensions`; correct any that are wrong in the seat list.
2. Each agent's phone must be signed in as their extension: the desk phone in the office, or a softphone (MicroSIP)
   on the SoftEther VPN from home. Call in the handset rings that phone first, then the customer.
3. The handset's home line says `Desk phone · the PBX rings ext …` in green when it is ready, or names what is missing.

## 10. Rollback

- Calls: clear the Telephony bridge URL in ConnectDesk (or set the driver to Simulated).
- SQL: delete `SERVICESUITE_RELAY_URL_MICROMART` on Vercel and redeploy. Micromart goes back to the shared relay.
- Remove everything here: `powershell -ExecutionPolicy Bypass -File install.ps1 -Remove`.

## 11. When something is wrong

| Symptom | Meaning |
|---|---|
| `…:8443/health` → 502, empty body | Funnel is up, nothing listens on 8787: `Get-Service LenderNodeSqlRelay`, then `logs\` |
| `…/health` times out from mobile data | Funnel not on for that port, or Tailscale stopped (unattended mode off, key expired) |
| `relay:verify` → 401 | The relay secret differs between `.env` and the workstation/Vercel value |
| Micromart reads work, outcomes fail with "read-only" | `SQL_RELAY_ALLOW_WRITES` here does not match servicesuite-in |
| Relay log: `Micromart Africa did not answer` | No road to the SQL address in `.env`: re-run `check-node.ps1` |
| PBX Test: "refused this server's IP" (20015) | Add the address the VERDICT printed to the PBX's API allowed IPs |
| Bridge log: `presented certificate …, not the pinned one` | The PBX's certificate changed: re-run `check-node.ps1`, update `PBX_TLS_PIN`, restart the bridge |
| PBX Test: "refused the API username or password" | The API password in ConnectDesk is not CollectBox's MD5 |
| Agents: "Extension … is not signed in" | Their phone or softphone is not registered: VPN up, softphone signed in as that extension |
| A service will not start after `.env` edits | The editor was not elevated and saved a copy elsewhere, or a value lost its quotes |

## 12. Updating

Build a new kit (`npm run build:lender-node`), copy `sql-relay.cjs` / `pbx-bridge.mjs` over the old ones, then
`Restart-Service LenderNodeSqlRelay` / `Restart-Service LenderNodePbxBridge`. `.env` and the services stay. `VERSION`
says which commit a kit was built from.
