// ─────────────────────────────────────────────────────────────────────────────
// THE TELEPHONY BRIDGE — a fixed IP for ConnectDesk to reach a PBX from, and the
// floor's minute-by-minute scheduler. No dependencies; Node 20+.
//
// 1. POST /pbx   ConnectDesk runs on Vercel, whose addresses change. A PBX whose
//                API only accepts listed IPs (Yeastar: Settings → System → API →
//                Allowed IP, error 20015) accepts this machine instead. Each
//                request is HMAC-signed by ConnectDesk (TelephonyConfig
//                bridgeSecret) and may only go to a PBX on PBX_ALLOW.
//    POST /pbx-file  the same, for a file the PBX serves by GET (a call recording).
// 2. The floor's scheduler: every minute it calls ConnectDesk's
//    /api/cron/desk-floor, so 08:00 starts the dialler and a break turns red
//    even when no screen is open.
//
//   BRIDGE_SECRET=…  PBX_ALLOW=197.248.179.183:8088  PORT=10001 \
//   CONNECTDESK_URL=https://connectdesk.servicesuitecloud.com  CRON_SECRET=… \
//   node server.mjs
//
// 3. A PBX on a private LAN (Micromart's S50, 192.168.1.150, reached over the
//    lender's VPN): run the bridge on a machine connected to that VPN. Its API
//    is HTTPS with the certificate the PBX shipped with, which no public CA
//    signs — so it is trusted by fingerprint, per host, in PBX_TLS_PIN:
//
//   PBX_ALLOW=192.168.1.150:8088  PBX_TLS_PIN=192.168.1.150:8088=AB:CD:…
// ─────────────────────────────────────────────────────────────────────────────
import http from "node:http";
import https from "node:https";
import tls from "node:tls";
import crypto from "node:crypto";
import fs from "node:fs";

// A `.env` beside this file, when there is one (a lender node keeps the SQL
// relay's settings and these in one file). The service's own environment wins.
try {
  for (const line of fs.readFileSync(new URL("./.env", import.meta.url), "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(["'])(.*)\1$/, "$2");
  }
} catch { /* no .env: the environment is the configuration */ }

const PORT = Number(process.env.BRIDGE_PORT || process.env.PORT || 10001);
const SECRET = process.env.BRIDGE_SECRET || "";
const ALLOW = new Set((process.env.PBX_ALLOW || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean));
const CONNECTDESK = (process.env.CONNECTDESK_URL || "").replace(/\/+$/, "");
const CRON_SECRET = process.env.CRON_SECRET || "";

const hex = (s) => String(s || "").replace(/[^0-9a-f]/gi, "").toUpperCase();
/** host:port → the SHA-256 fingerprint its certificate must have. Never "accept any certificate". */
const PINS = new Map(
  (process.env.PBX_TLS_PIN || "").split(",").map((s) => s.trim()).filter(Boolean).map((s) => {
    const i = s.lastIndexOf("=");
    return [s.slice(0, i).trim().toLowerCase(), hex(s.slice(i + 1))];
  }),
);

if (!SECRET || SECRET.length < 24) { console.error("BRIDGE_SECRET (24+ chars) is required"); process.exit(1); }
if (!ALLOW.size) { console.error("PBX_ALLOW (host:port list) is required"); process.exit(1); }

const log = (...a) => console.log(new Date().toISOString(), ...a);

/**
 * fetch() for a PBX. Plain fetch for http (Fastdial). For https, node:https on
 * a socket whose certificate has already been checked against the pin, so not
 * one byte of the request (the API password included) goes to anything else.
 * An unpinned https host is refused with the fingerprint it presented, to be
 * compared with the PBX's own certificate screen and then pinned.
 */
function pbxFetch(url, { method = "GET", headers = {}, body, timeoutMs }) {
  if (url.protocol !== "https:") return fetch(url, { method, headers, body, signal: AbortSignal.timeout(timeoutMs) });
  const pin = PINS.get(url.host.toLowerCase());
  return new Promise((resolve, reject) => {
    const req = https.request(url, {
      method, headers, signal: AbortSignal.timeout(timeoutMs),
      createConnection: (_opts, done) => {
        const s = tls.connect({ host: url.hostname, port: Number(url.port || 443), rejectUnauthorized: false });
        s.setTimeout(timeoutMs, () => s.destroy(new Error("TLS handshake timed out")));
        s.once("error", done);
        s.once("secureConnect", () => {
          const got = hex(s.getPeerCertificate()?.fingerprint256);
          if (pin && got === pin) { s.setTimeout(0); return done(null, s); }
          s.destroy();
          done(new Error(pin ? `${url.host} presented certificate ${got}, not the pinned one` : `${url.host} is HTTPS with certificate ${got}; set PBX_TLS_PIN=${url.host}=${got} once it matches the PBX`));
        });
      },
    }, (res) => resolve({
      status: res.statusCode ?? 502,
      headers: { get: (n) => { const v = res.headers[n.toLowerCase()]; return Array.isArray(v) ? v.join(", ") : v ?? null; } },
      body: res,
      text: async () => { let t = ""; res.setEncoding("utf8"); for await (const c of res) t += c; return t; },
    }));
    req.on("error", reject);
    req.end(body);
  });
}

function verify(ts, sig, raw) {
  const t = Number(ts);
  if (!Number.isFinite(t) || Math.abs(Date.now() - t) > 60_000) return false;
  const want = crypto.createHmac("sha256", SECRET).update(`${ts}.${raw}`).digest("hex");
  const a = Buffer.from(want), b = Buffer.from(String(sig || ""));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const server = http.createServer((req, res) => {
  const send = (code, body) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(typeof body === "string" ? body : JSON.stringify(body)); };
  if (req.method === "GET" && req.url === "/health") return send(200, { ok: true, allow: [...ALLOW], pinned: [...PINS.keys()], scheduler: !!(CONNECTDESK && CRON_SECRET) });
  if (req.method === "POST" && req.url === "/pbx-file") return pbxFile(req, res, send);
  if (req.method !== "POST" || req.url !== "/pbx") return send(404, { ok: false });
  let raw = "";
  req.on("data", (c) => { raw += c; if (raw.length > 64_000) req.destroy(); });
  req.on("end", async () => {
    if (!verify(req.headers["x-bridge-ts"], req.headers["x-bridge-sig"], raw)) return send(401, { ok: false, message: "bad signature" });
    let p;
    try { p = JSON.parse(raw); } catch { return send(400, { ok: false }); }
    let url;
    try { url = new URL(p.url); } catch { return send(400, { ok: false, message: "bad url" }); }
    if (url.protocol !== "http:" && url.protocol !== "https:") return send(400, { ok: false });
    if (!ALLOW.has(url.host.toLowerCase())) return send(403, { ok: false, message: `${url.host} is not on PBX_ALLOW` });
    try {
      const r = await pbxFetch(url, { method: "POST", headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(p.body ?? {}), timeoutMs: 8000 });
      const text = await r.text();
      log("pbx", url.pathname, r.status);
      res.writeHead(r.status, { "Content-Type": "application/json" });
      res.end(text);
    } catch (e) {
      log("pbx error", url.pathname, e?.cause?.message ?? e?.message);
      send(502, { ok: false, message: "PBX unreachable from the bridge" });
    }
  });
});
// Loopback by default: Tailscale Funnel connects to it locally, and nothing on
// the LAN or the tailnet has any business reaching it directly.
const HOST = process.env.BRIDGE_HOST || "127.0.0.1";
server.listen(PORT, HOST, () => log(`telephony bridge on ${HOST}:${PORT}; allow ${[...ALLOW].join(", ")}${PINS.size ? `; pinned ${[...PINS.keys()].join(", ")}` : ""}`));

// POST /pbx-file {url} — a file the PBX serves by GET (a call recording),
// streamed back as the PBX sent it. Same signature and allow-list as /pbx.
function pbxFile(req, res, send) {
  let raw = "";
  req.on("data", (c) => { raw += c; if (raw.length > 8_000) req.destroy(); });
  req.on("end", async () => {
    if (!verify(req.headers["x-bridge-ts"], req.headers["x-bridge-sig"], raw)) return send(401, { ok: false, message: "bad signature" });
    let url;
    try { url = new URL(JSON.parse(raw).url); } catch { return send(400, { ok: false, message: "bad url" }); }
    if (url.protocol !== "http:" && url.protocol !== "https:") return send(400, { ok: false });
    if (!ALLOW.has(url.host.toLowerCase())) return send(403, { ok: false, message: `${url.host} is not on PBX_ALLOW` });
    try {
      const r = await pbxFetch(url, { timeoutMs: 30_000 });
      const headers = { "Content-Type": r.headers.get("content-type") || "application/octet-stream" };
      const len = r.headers.get("content-length");
      if (len) headers["Content-Length"] = len;
      res.writeHead(r.status, headers);
      let sent = 0;
      for await (const chunk of r.body) {
        sent += chunk.length;
        if (sent > 128 * 1024 * 1024) { res.destroy(); return; }
        res.write(chunk);
      }
      res.end();
      log("pbx-file", url.pathname, r.status, sent);
    } catch (e) {
      log("pbx-file error", url.pathname, e?.message);
      if (!res.headersSent) send(502, { ok: false, message: "PBX unreachable from the bridge" });
      else res.destroy();
    }
  });
}

// ── The floor's scheduler ────────────────────────────────────────────────────
if (CONNECTDESK && CRON_SECRET) {
  const tick = async () => {
    try {
      const r = await fetch(`${CONNECTDESK}/api/cron/desk-floor`, { headers: { authorization: `Bearer ${CRON_SECRET}` }, signal: AbortSignal.timeout(55_000) });
      if (!r.ok) log("floor tick", r.status);
    } catch (e) { log("floor tick failed", e?.message); }
  };
  setInterval(tick, 60_000);
  void tick();
  log("floor scheduler: every 60 s →", CONNECTDESK);
}
